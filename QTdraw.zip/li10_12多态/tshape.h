#ifndef TSHAPE_H
#define TSHAPE_H

//#pragma once
typedef unsigned int uint;
typedef unsigned char uchar;
class TShape{
private:
      uint _x, _y;        							//几何形状的位置
protected:
      /*声明几何形状的颜色。允许TShape的派生类直接访问这些颜色属性，
       *而不允许在类外通过类的对象直接访问这些属性        */
      uchar _RED, _GREEN, _BLUE;
public:
      TShape(uint x, uint y);
      virtual ~TShape();
      void getXY(uint& x, uint& y);
      void setXY(uint x, uint y);
      virtual void Draw()=0;
      void getRGB(uchar& R, uchar& G, uchar& B);
      void setRGB(uchar R, uchar G, uchar B);
};

#endif // TSHAPE_H
