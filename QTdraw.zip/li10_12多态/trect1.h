#ifndef TRECT_H
#define TRECT_H

#pragma once
#include "TShape.h"
#include <iostream>
using namespace std;
class TRect : public TShape {
protected:
    uint _width, _height;
public:
    TRect(uint width, uint height, uint x, uint y);
    ~TRect();
    void Draw();
    void getter(uint& width, uint& height) const;
    void setter(uint width, uint height);
}

#endif // TRECT_H
