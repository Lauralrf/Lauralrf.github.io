#ifndef TRECTA_H
#define TRECTA_H

#include "TShape.h"
class TRecta: public TShape {
protected:
      uint _width, _height;
public:
      TRecta(uint width, uint height, uint x, uint y);
      ~TRecta();
      void Draw();
      void getter(uint& width, uint& height);
      void setter(uint width, uint height);
};


#endif // TRECTA_H
