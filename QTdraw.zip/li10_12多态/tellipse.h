#ifndef TELLIPSE_H
#define TELLIPSE_H

#include "TShape.h"
class TEllipse: public TShape {
protected:
      uint _longR, _shortR;
public:
      TEllipse(uint longR, uint shortR, uint x, uint y);
      ~TEllipse();
      void Draw();
      void getR(uint& longR, uint& shortR);
      void setR(uint longR, uint shortR);
};

#endif // TELLIPSE_H
