#include <QCoreApplication>
#include "TEllipse.h"
#include "trecta.h"

#include <iostream>
using namespace std;
int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
/*
    TEllipse e(4u,4u,20u,15u);
    e.Draw();
    TRecta r1(10u,5u,20u,25u);
    r1.Draw();
    TRecta r2(6u,20u,12u,35u);
    r2.Draw();
    TRecta r3(6u,20u,28u,35u);
    r3.Draw();

    TShape *ps[4];
    ps[0] = &e;
    ps[1] = &r1;
    ps[2] = &r2;
    ps[3] = &r3;
    for (int i=0;i<4;i++)
        ps[i]->Draw();
*/
    TShape *ps[4];
    ps[0] = new TEllipse(4u,4u,20u,15u);
    ps[1] = new TRecta(10u,5u,20u,25u);
    ps[2] = new TRecta(6u,20u,12u,35u);
    ps[3] = new TRecta(6u,20u,28u,35u);
    for (int i=0;i<4;i++)
    {
        ps[i]->Draw();
        delete ps[i];
    }

    return a.exec();
}
