#include "trecta.h"
#include <iostream>
using namespace std;

TRecta::TRecta(uint width, uint height,uint x, uint y):TShape(x,y){
      _width  = width;
      _height = height;
     //在派生类构造函数中初始化基类保护成员
     _RED    = 0x00;
     _GREEN = 0xff;
     _BLUE  = 0x00;
}
TRecta::~TRecta(){
    cout<<"TRect destructed"<<endl;
}
void TRecta::Draw(){
      uint x, y;
      getXY(x, y);       				//调用基类函数获取椭圆的圆心坐标
      cout<<"Draw an ellipse with color(";
    cout<<static_cast<uint>(_RED)   <<","
                       <<static_cast<uint>(_GREEN)<<","
                       <<static_cast<uint>(_BLUE);	cout<<") at point(";
//  cout<<_x<<","<<_y<<")"<<endl; //错误！在派生类中不能访问基类私有成员
    cout<< x<<","<< y<<"), width: ";
    cout<<_width<<" and height: "<<_height<<endl;
}
void TRecta::getter(uint& width, uint& height){
      width  = _width;
      height = _height;
}
void TRecta::setter(uint width, uint height){
      _width  = width;
      _height = height;
}
