#include "TEllipse.h"
#include <iostream>
using namespace std;
TEllipse::TEllipse(uint longR, uint shortR,uint x, uint y):TShape(x,y){
      _longR  = longR;
      _shortR = shortR;
     //在派生类构造函数中初始化基类保护成员
     _RED    = 0xff;
     _GREEN = 0x00;
     _BLUE  = 0x00;
}
TEllipse::~TEllipse(){
    cout<<"TEllipse destructed"<<endl;
}
void TEllipse::Draw(){
      uint x, y;
      getXY(x, y);       				//调用基类函数获取椭圆的圆心坐标
      cout<<"Draw an ellipse with color(";
    cout<<static_cast<uint>(_RED)   <<","
                       <<static_cast<uint>(_GREEN)<<","
                       <<static_cast<uint>(_BLUE);	cout<<") at point(";
//  cout<<_x<<","<<_y<<")"<<endl; //错误！在派生类中不能访问基类私有成员
    cout<< x<<","<< y<<"), longR: ";
    cout<<_longR<<" and shortR: "<<_shortR<<endl;
}
void TEllipse::getR(uint& longR, uint& shortR){
      longR  = _longR;
      shortR = _shortR;
}
void TEllipse::setR(uint longR, uint shortR){
      _longR  = longR;
      _shortR = shortR;
}
