#include "trect.h"
#include <iostream>
using namespace std;
TRect::TRect(uint width, uint height,uint x, uint y):TShape(x,y){
    _width  = width;
    _height = height;
     _RED    = 0x00;
     _GREEN = 0xff;
     _BLUE  = 0x00;
}
TRect::~TRect(){
    cout<<"TRect destructed"<<endl;
}
void TRect::Draw(){
    uint x, y;
    getXY(x, y);       //调用基类公有函数访问基类私有成员
    cout<<"Draw a rectangle with color(";
     cout<<static_cast<uint>(_RED)   <<","
                       <<static_cast<uint>(_GREEN)<<","
                       <<static_cast<uint>(_BLUE);	cout<<") at point(";
cout<< x<<","<< y<<"), width: ";
    cout<<_width<<" and height: "<<_height<<endl;
}
void TRect::getter(uint& width, uint& height) const{
    width = _width;
    height = _height;
}
void TRect::setter(uint width, uint height){
    _width = width;
    _height = height;
}
