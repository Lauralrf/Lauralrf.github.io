#include "tshape.h"

#include <iostream>
using namespace std;
TShape::TShape(uint x, uint y){
     _x = x;
     _y = y;
    _RED = 0;
    _GREEN = 0;
    _BLUE = 0;
}
TShape::~TShape(){
cout<<"TShape destructed"<<endl;
}

void TShape::Draw(){
     cout<<"Draw a shape with color("<<static_cast<uint>(_RED)<<","
<<static_cast<uint>(_GREEN)<<","<<static_cast<uint>(_BLUE);
     cout<<") at point("<<_x<<","<<_y<<")"<<endl;
}
void TShape::getXY(uint& x, uint& y){
      x = _x;
      y = _y;
}
void TShape::setXY(uint x, uint y){
      _x = x;
      _y = y;
}
void TShape::getRGB(uchar& R, uchar& G, uchar& B){
      R = _RED;
      G = _GREEN;
      B = _BLUE;
}
void TShape::setRGB(uchar R, uchar G, uchar B){
      _RED = R;
      _GREEN = G;
      _BLUE = B;
}
