#include <QCoreApplication>
#include "TEllipse.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    TEllipse elps(10u,5u, 20u,30u);
    elps.setRGB(0x00, 0x00, 0xff);	//调用基类函数访问基类保护成员
//   elps._RED=0x10;  					//错误！用户代码不能通过派生类对象访问基类保护成员
   elps.Draw();   					//调用TEllipse::Draw()而非TShape::Draw()

    return a.exec();
}
