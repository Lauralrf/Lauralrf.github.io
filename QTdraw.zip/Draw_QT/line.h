#ifndef LINE_H
#define LINE_H

#include "shape.h"

class Line : public Shape
{
public:
        Line(){};

        void paint(QPainter &painter)
        {
                painter.drawLine(start, end);
        }
};

#endif // LINE_H
