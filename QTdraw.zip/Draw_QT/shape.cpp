#include "shape.h"

Shape::Shape()
{
//    start=QPoint(x1,y1);
//    end=QPoint(x2,y2);
}
