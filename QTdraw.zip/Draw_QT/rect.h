#ifndef RECT_H
#define RECT_H

#include "shape.h"

class Rect : public Shape
{
public:
        Rect(){};

        void paint(QPainter &painter)
        {
                painter.drawRect(start.x(), start.y(),
                                                 end.x() - start.x(), end.y() - start.y());
        }
};

#endif // RECT_H
