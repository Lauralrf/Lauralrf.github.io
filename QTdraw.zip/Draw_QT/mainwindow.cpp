#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QtGui>
#include "shape.h"
#include "line.h"
#include "rect.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

void MainWindow::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    painter.setBrush(Qt::white);
    painter.drawRect(0, 0, size().width(), size().height());

    painter.setPen(Qt::blue);
    painter.setFont(QFont("Arial", 28));
    painter.drawText(rect(), Qt::AlignCenter, "robot");

        Shape* sh;
        sh = new Rect;
        sh->setStart(QPoint(10,25));
        sh->setEnd(QPoint(80,45));
        sh->paint(painter);
        delete sh;
        sh = new Line;
        sh->setStart(QPoint(30,50));
        sh->setEnd(QPoint(30,100));
        sh->paint(painter);
        delete sh;
        sh = new Line;
        sh->setStart(QPoint(60,50));
        sh->setEnd(QPoint(60,100));
        sh->paint(painter);
        delete sh;

}

MainWindow::~MainWindow()
{
    delete ui;
}
