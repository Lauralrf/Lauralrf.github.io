# -*- coding: utf-8 -*-
"""
Created on Fri May 19 16:54:04 2017

@author: Administrator
"""

import cv2
import numpy as np
fn="view.jpg"

if __name__ == '__main__':
    print('loading %s ...' %fn)
    img = cv2.imread(fn)
    sp = img.shape

    img_gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)

    cv2.imshow('img_gray',img_gray)
    cv2.waitKey()
    cv2.destroyAllWindows()
    
    count=50000
    for k in range(0,count):
        xi = int(np.random.uniform(0,sp[1]))
        xj = int(np.random.uniform(0,sp[0]))        
        if img.ndim == 2:
            img[xj,xi] = 255
        elif img.ndim == 3:
            img[xj,xi,0] = 25
            img[xj,xi,1] = 20
            img[xj,xi,2] = 20
               
    cv2.imshow('img_noising',img)
    cv2.waitKey()
    cv2.destroyAllWindows()
               