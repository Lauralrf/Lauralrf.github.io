# -*- coding: utf-8 -*-
"""
Created on Fri May 19 16:54:04 2017

@author: Administrator
"""

import cv2
import numpy as np
fn="view.jpg"

if __name__ == '__main__':
    print('loading %s ...' %fn)
    img = cv2.imread(fn)
    sp = img.shape
    print(sp)
    cv2.imshow('preview',img)
    cv2.waitKey()
    cv2.destroyAllWindows()
    
    for xi in range(0,sp[1]):
        for xj in range(0,sp[0]):
            #将像素值整体变大，亮度增加
            img[xj,xi,0] = int(img[xj,xi,0]*2)
            img[xj,xi,1] = int(img[xj,xi,1]*2)
            img[xj,xi,2] = int(img[xj,xi,2]*2)
    cv2.imwrite("brighten.jpg",img)
    cv2.imshow('brighten',img)
    cv2.waitKey()
    cv2.destroyAllWindows()
