# -*- coding: utf-8 -*-
"""
Created on Sat May 20 15:00:36 2017

@author: Administrator
"""
'''
import cv2  
import numpy as np  
  
img = cv2.imread("view.jpg")  
  
gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)  
  
# surf.hessianThreshold=3000  
surf = cv2.SURF(3000)  
  
kp,res = surf.detectAndCompute(gray,None)  
print( res.shape  )
  
img = cv2.drawKeypoints(img,kp,None,(255,0,255),4)  
print(len(kp))  
  
cv2.namedWindow("SURF")  
cv2.imshow("SURF", img)  
cv2.waitKey(0)  
cv2.destroyAllWindows()  
'''

import cv2
 
img = cv2.imread('view.jpg')
gray= cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
 
surf = cv2.xfeatures2d.SURF_create()
kp = surf.detect(gray,None)
 
img = cv2.drawKeypoints(gray, kp, img)
 
cv2.imshow("img", img)
 
k = cv2.waitKey(0)
if k & 0xff == 27:
    cv2.destroyAllWindows()