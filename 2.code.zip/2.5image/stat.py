# -*- coding: utf-8 -*-
"""
Created on Thu May 18 19:54:00 2017

@author: Administrator
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
x= np.random.randn(1000) #产生1000个符合正态分布的随机数
plt.hist(x,10) #分成10组绘制直方图
plt.show()
D = pd.DataFrame([x,x+1]).T #生成两列数据
D.boxplot()
plt.show()
print(D.describe())
print(D.corr())
print(D.cov())
print(D.skew())
