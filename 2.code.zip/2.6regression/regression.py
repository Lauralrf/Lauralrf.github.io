# -*- coding: utf-8 -*-
"""
Created on Tue May  9 20:57:48 2017

@author: pris
"""

import numpy as np
#x_train = np.matrix([[7,2,3],[3,7,17],[11,3,5]],dtype=np.float64)
#y_train = np.matrix([28,40,44],dtype=np.float64).T
#a=(x_train.T*x_train).I*x_train.T*y_train

x_train = np.matrix([    [1, 2],    [2, 1],    [2, 3],    [3, 5],    [1, 3],    [4, 2],    [7, 3],    [4, 5],    [11, 3],    [8, 7]    ],dtype=np.float64)
y_train = np.matrix([7, 8, 10, 14, 8, 13, 20, 16, 28, 26],dtype=np.float64).T
a=(x_train.T*x_train).I*x_train.T*y_train

i=0
cb=[]
while i<a.size:
    cb.append(a[i,0])
    i+=1
temp_b0=y_train-x_train*a
b0=temp_b0.sum()/temp_b0.size

temp_e=abs(b0+x_train*a-y_train)
e=temp_e.sum()/temp_e.size
