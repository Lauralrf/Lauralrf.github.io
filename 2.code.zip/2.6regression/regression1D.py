# -*- coding: utf-8 -*-
"""
Created on Tue May  9 09:19:59 2017

@author: pris
"""

import matplotlib.pyplot as plt
x=[1,2,3,3,6,12,11]
y=[3,5,8,5,12,26,20]
x_y=map((lambda x,y:x*y),x,y)
x_pow2=map((lambda x:x**2),x)
s1=sum(x_y)
s2=sum(x_pow2)
#a=float((sum(x_y)*len(x)-sum(x)*sum(y)))/(sum(x_pow2)*len(x)-sum(x)**2)

a=float((s1*len(x)-sum(x)*sum(y)))/(s2*len(x)-sum(x)**2)
b=float(sum(y)-a*sum(x))/len(x)
plt.xlabel('X')
plt.ylabel('Y')
plt.plot(x,y,'*')
plt.plot([0,15],[0*a+b,15*a+b])
plt.grid()
plt.title("{0}*x+{1}".format(a,b))
plt.show()
