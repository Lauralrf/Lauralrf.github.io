# -*- coding: utf-8 -*-
"""
Created on Thu May 18 22:27:56 2017

@author: Administrator
"""

from sklearn import datasets
iris = datasets.load_iris()
X, y = iris.data, iris.target

import matplotlib.pyplot as plt
data = X[:,[1,3]] # 为了便于可视化，只取两个维度

k=2
from sklearn.cluster import KMeans
model = KMeans(n_clusters = k, n_jobs = 1, max_iter = 100) #分为k类
model.fit(data) #开始聚类

centroids = model.cluster_centers_
print(model.labels_)

data0 = data[model.labels_==0]
data1 = data[model.labels_==1]
fig, (ax1,ax2) = plt.subplots(1,2,figsize=(12,5))
ax1.scatter(data[:,0],data[:,1],c='c',s=30,marker='o')
ax2.scatter(data0[:,0],data0[:,1],c='r')
ax2.scatter(data1[:,0],data1[:,1],c='c')
ax2.scatter(centroids[:,0],centroids[:,1],c='b',s=120,marker='o')
plt.show()

import numpy as np
data = np.append(data0,data1,axis = 0) #xxx
'''
centroids0 = centroids[0]           #xxx
centroids0 = np.tile(centroids0, (len(data0[:,0]),1))#xxx
data0 = data0-centroids0            #xxx
centroids1 = centroids[1]           #xxx
centroids1 = np.tile(centroids1, (len(data1[:,0]),1))#xxx
data1 = data1-centroids1            #xxx
data_temp = np.append(data0, data1, axis = 0)#xxx
'''
data_temp= []
for i in range(k):
    temp = data[model.labels_==i] - centroids[i]
    data_temp = np.vstack((data_temp,temp))
#    data_temp.extend(temp)
print(data_temp)
#data_temp = np.append(data_temp[0], data_temp[1], axis = 0)


discrete_points =data[data_temp[:,0]*data_temp[:,0]+data_temp[:,1]*data_temp[:,1] > 0.5] #离群点
normal_points =data[data_temp[:,0]*data_temp[:,0]+data_temp[:,1]*data_temp[:,1] <= 0.5] #离群点
plt.scatter(discrete_points[:,0],discrete_points[:,1],c='r',marker='x')
plt.scatter(normal_points[:,0],normal_points[:,1],c='c')
plt.show()
