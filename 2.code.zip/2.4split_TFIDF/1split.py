import jieba
seg_list = jieba.cut("我来到北京邮电大学", cut_all = True)
print ("Full Mode:", ' '.join(seg_list))

seg_list = jieba.cut("我来到北京邮电大学")
print ("Default Mode:", ' '.join(seg_list))
