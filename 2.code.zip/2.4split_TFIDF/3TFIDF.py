# -*- coding: utf-8 -*-
import jieba
import math
import os

with open("stop_words.txt", encoding="utf-8") as f:
    stop_words = [s.strip() for s in f.readlines()]
    stop_words.insert(1, " ")
#    stop_words.insert(2, "")
    f.close()


class TEXT(object): 
    def __init__(self):
        self.word_idf = {}

    def word_split(self, doc_path):
        self.word_dict = {}
        with open(doc_path, encoding="utf-8") as f:
            paragraphs = [s.strip() for s in f.readlines() if s.strip() != ""]
            for para in paragraphs:
                split_words = list(jieba.cut(para))
                # 去标点以及停用词
                split_words = list(set(split_words)-set(stop_words))
                for i in split_words:
                    self.word_dict[i] = self.word_dict.get(i, 0) + 1
            f.close()
        return self.word_dict    

    def tf_func(self):
        self.word_tf = {}
        total_count = sum(self.word_dict.values())
        for word in self.word_dict.keys():
            self.word_tf[word] = float(self.word_dict[word])/total_count
        return self.word_tf  

    def idf_func(self, all_words, length):
        for word in list(set(all_words)):
            self.word_idf[word] = math.log(length/all_words.count(word))
        return self.word_idf

    def tf_idf_func(self, word_dict, word_tf):
        self.word_tf_idf = {}
        for word in word_dict.keys():
            self.word_tf_idf[word] = word_tf[word] * self.word_idf[word]
        return self.word_tf_idf

def output(file_path):
    docs = os.listdir(file_path)
    length = len(docs)
    all_words = []
    docs_dict = {}
    a = TEXT()
    for doc in docs:
        docs_dict[doc] = {}
        doc_path = file_path + "\\" + doc
        word_dict = a.word_split(doc_path)
        all_words.extend(word_dict.keys())
        docs_dict[doc]["word_dict"] = word_dict
        word_tf = a.tf_func()
        docs_dict[doc]["tf"] = word_tf
    word_idf = a.idf_func(all_words, length)
    docs_dict["idf"] = word_idf
    for doc in docs:
        word_tf_idf = a.tf_idf_func(docs_dict[doc]["word_dict"], docs_dict[doc]["tf"])
        docs_dict[doc]["tf_idf"] = word_tf_idf
    print ("="*40)
    print ("idf")
    word_idf = sorted(docs_dict["idf"].items(), key=lambda x: x[1], reverse=True)
    for word in word_idf:
        print (word[0], word[1])
    for doc in docs:
        print ("="*40)
        print (doc)
        print ("\nword_dict")
        word_dict = sorted(docs_dict[doc]["word_dict"].items(), key=lambda x: x[1], reverse=True)
        for word in word_dict:
            print (word[0], word[1])
        print ("\ntf")
        word_tf = sorted(docs_dict[doc]["tf"].items(), key=lambda x: x[1], reverse=True)
        for word in word_tf:
            print (word[0], word[1])
        print ("\ntf-idf")
        word_tf_idf = sorted(docs_dict[doc]["tf_idf"].items(), key=lambda x: x[1], reverse=True)
        for word in word_tf_idf:
            print (word[0], word[1])

if __name__ == '__main__':
    output(r"D:\2016PGM\code\split_TFIDF\dataset3")
    
