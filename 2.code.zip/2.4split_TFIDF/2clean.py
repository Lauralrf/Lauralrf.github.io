# -*- coding: utf-8 -*-

import jieba

with open("stop_words.txt", encoding="utf-8") as f:
    stop_words = [s.strip() for s in f.readlines()]
    stop_words.insert(1, " ")
    stop_words.insert(2, "")
    f.close()

word_dict = {}
with open("test2.txt", encoding="utf-8") as f:
    paragraphs = [s.strip() for s in f.readlines() if s.strip() != ""]
    for para in paragraphs:
        split_words = list(jieba.cut(para))
        # 去标点以及停用词
        split_words = list(set(split_words)-set(stop_words))
        for i in split_words:
            word_dict[i] = word_dict.get(i, 0) + 1

    f.close()

print ("Default Mode:", ' '.join(word_dict))
