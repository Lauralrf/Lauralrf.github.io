#! /usr/bin/env python
# -*- coding: utf-8 -*-

import urllib.request
import re, os

#----------- 处理页面上的各种标签 -----------
class HTML_Tool:
    BgnCharToNoneRex = re.compile("(\t|\n| |<a.*?>|<img.*?>)")

    EndCharToNoneRex = re.compile("<.*?>")

    BgnPartRex = re.compile("<p.*?>")
    CharToNewLineRex = re.compile("(<br/>|</p>|<tr>|<div>|</div>)")
    CharToNextTabRex = re.compile("<td>")

    replaceTab = [("<","<"),(">",">"),("&","&"),("&","\""),(" "," ")]
    
    def Replace_Char(self,x):
        x = self.BgnCharToNoneRex.sub("",x)
        x = self.BgnPartRex.sub("\n    ",x)
        x = self.CharToNewLineRex.sub("\n",x)
        x = self.CharToNextTabRex.sub("\t",x)
        x = self.EndCharToNoneRex.sub("",x)

        for t in self.replaceTab:  
            x = x.replace(t[0],t[1])  
        return x  
    
class Baidu_Spider:
    def __init__(self,url):  
        self.myUrl = url + '?see_lz=1'
        #self.myUrl = url
        self.datas = []
        self.datas.append(url+'\r\n')
        self.myTool = HTML_Tool()
        #print u'启动爬虫程序'
  
    def GetContent(self,snum):
        myPage = urllib.request.urlopen(self.myUrl).read().decode("utf-8")     #response = urllib2.urlopen('http://www.google.com', timeout=10)
        endPage = self.page_counter(myPage)
        title = self.find_title(myPage)
        print (u'文章名称：' + title)
        print (type(title))
        self.datas.append(title+'\r\n')
        # 获取最终的数据
        self.save_data(self.myUrl,title,endPage,snum)

    def page_counter(self,myPage):
        myMatch = re.search(r'class="red">(\d+?)</span>', myPage, re.S)
        if myMatch:
            endPage = int(myMatch.group(1))
        else:
            endPage = 0
            print (u'爬虫报告：无法计算楼主发布内容有多少页！')
        return endPage

    def find_title(self,myPage):

        myMatch = re.search(r'<h1.*?>(.*?)</h1>', myPage, re.S)
        title = u'暂无标题'
        if myMatch:
            title  = myMatch.group(1)
        else:
            print (u'爬虫报告：无法加载文章标题！')
        # 文件名不能包含以下字符： \ / ： * ? " < > |
        title = title.replace('\\','').replace('/','').replace(':','').replace('*','').replace('?','').replace('"','').replace('>','').replace('<','').replace('|','')
        return title


    def save_data(self,url,title,endPage,snum):
        self.get_data(url,endPage)
        if os.path.exists('./result/') == False:
            os.makedirs('./result/')
        f = open('./result/'+snum+'.txt','w+')
        f.writelines(self.datas)
        f.close()
        print (u'爬虫报告：文件已下载到本地并打包成txt文件')

    def get_data(self,url,endPage):
        url = url + '&pn='
        for i in range(1,endPage+1):
            myPage = urllib.request.urlopen(url + str(i)).read().decode("utf-8")
            self.deal_data(myPage)

    def deal_data(self,myPage):
        myItems = re.findall('id="post_content.*?>(.*?)</div>',myPage,re.S)
        for item in myItems:
            data = self.myTool.Replace_Char(item.replace("\n",""))
            self.datas.append(data+'\r\n')


def GetPostsUrl(url):
    myPage = urllib.request.urlopen(url).read().decode("utf-8")
    myUrl = re.findall(r'href="/p/(\d+?)"', myPage, re.S)
    if myUrl:
        return myUrl
    else:
        print (u'爬虫报告：无法获得帖子')

def PostsPage(url,endPage):
    for i in range(0,endPage):
        newUrl = url + '&pn=' + str(i*50)
        print (newUrl)
        myUrl = GetPostsUrl(newUrl)
        for item in myUrl:
            PostsUrl = 'http://tieba.baidu.com/p/'+ item
            print (PostsUrl)
            mySpider = Baidu_Spider(PostsUrl)
            mySpider.GetContent(item)
	
#-----------------------------------
if __name__ == '__main__':
    url = 'http://tieba.baidu.com/f?kw=%E6%97%85%E8%A1%8C'
    PostsPage(url,10)
	
	
    #url = 'http://tieba.baidu.com/p/2962501715'
    #print u'请输入贴吧的地址最后的数字串：'
    #url = 'http://tieba.baidu.com/p/' + str(raw_input(u'http://tieba.baidu.com/p/')) 
    #print url
    #mySpider = Baidu_Spider(url)
    #mySpider.GetContent()
    
    
