# -*- coding: utf-8 -*-
"""
Created on Tue Sep  5 09:49:50 2017

@author: liurf
"""

import numpy
from scipy.misc import logsumexp
import os
import codecs
import re

_gradient = None  #  global variable used to store the gradient calculated in Liklihood function.


def logdotexp_vec_mat(loga,logM):
        return logsumexp(loga+logM,axis=1)
        
def logdotexp_mat_vec(logM,logb):
    return logsumexp(logM+logb[:,numpy.newaxis],axis=0)

def validTemplateLine(strt):
   ifvalid=True
   if strt.count("[")!=strt.count("]"):
       ifvalid=False
   if "UuBb".find(strt[0])==-1:
       ifvalid=False
   if ifvalid==False:
       print( "error in template file:", strt)
   return ifvalid

def readData(dataFile):
    texts = []
    labels = []
    text = []
    label=[]
    obydic=dict()
    file = codecs.open(dataFile, 'r', encoding='utf-8')  #  default encoding.
    obyid=0
    linecnt=0
    spacecnt=0
    for line in file:
        #print line
        line = line.strip()
        if len(line) == 0:
            if len(text)>0:
                texts.append(text)
                labels.append(label)
            text = []
            label = []
        else:
            linecnt+=1
            if linecnt % 10000 == 0 :
                print( "read ",linecnt , " lines.")
            chunk = line.split()
            if spacecnt==0:
                spacecnt=len(chunk)
            else:
                if len(chunk)!=spacecnt:
                    print( "Error in input data:",line)
            text.append(chunk[0:-1])
            ylabel=chunk[-1]
            if ylabel in obydic:
                label.append(obydic[ylabel])
            else:
                obydic[ylabel]=obyid
                label.append(obyid)
                obyid+=1
              
    if len(text)>0:  # sometimes, there is no empty line at the end of file.
        texts.append(text)
        labels.append(label)
    
    #print texts,labels
    texts=texts
    oys=labels
    seqnum=len(oys)
    seqlens=[len(x) for x in texts]
    K = len(obydic)
    y2label = dict([(obydic[key],key) for key in obydic.keys()])
    print ("number of labels:", K)
    return texts,seqlens,oys,seqnum,K,obydic,y2label
   
def readTemplate(tmpFile):
    tlist=[]  # list of list(each template line)  
    file = codecs.open(tmpFile, 'r')  #  default encoding.
    #repat=r'\[\d+,\d+\]'
    repat=r'\[-?\d+,-?\d+\]'    #-?[0-9]*
    for line in file:
        #print line    
        line=line.strip()
        if len(line)==0:
            continue
        if line[0]=="#":  # not comment line
            continue
        fl=line.find("#")
        if fl!=-1:  # remove the comments in the same line.
            line=line[0:fl]
        if validTemplateLine(line)==False:
            continue
        fl=line.find(":")
        if fl!=-1:  # just a symbol
            eachlist=[line[0:fl]]
        else:
            eachlist=[line[0]]
            
        for a in list(re.finditer(repat, line)):
            locstr=line[a.start()+1:a.end()-1]
            loc = locstr.split(",")
            eachlist.append(loc) 
            #print a.start(),a.end()
        tlist.append(eachlist)
    print ("Valid Template Line Number:",len(tlist))
    return tlist


def expandOBX(texts,seqid,locid,tp):  # expend the observation at locid for sequence(seqid)
    strt=tp[0]
    for li in tp[1::]:
        row=locid+int(li[0]); col=int(li[1])
        if row>=0 and row<len(texts[seqid]):
            if col>=0 and col<len(texts[seqid][row]):
                strt+= ":" + texts[seqid][row][col]
    #print strt
    return strt       

    
def processFeatures(tplist,texts,seqnum,K,fd=1):
    uobxs =  dict(); bobxs=dict() ; 
    '''add feature reduction here'''
    for ti,tp in enumerate(tplist):  # for each template line
        for sid in range(seqnum):  # for each traning sequence.
            for lid in range(len(texts[sid])):
                obx=expandOBX(texts,sid,lid,tp)
                if obx[0]=="B":
                    if obx in bobxs:
                        tval= bobxs[obx]
                        bobxs[obx]= tval+1
                    else:
                        bobxs[obx]=1
                        
                if obx[0]=="U":
                    if obx in uobxs:
                        tval= uobxs[obx]
                        uobxs[obx]= tval+1
                    else:
                        uobxs[obx]=1
                        
    if fd>=2:  # need to remove ub frequency less than fd
        uobxnew = { k : v for k,v in uobxs.iteritems() if v >= fd }
        bobxnew = { k : v for k,v in bobxs.iteritems() if v >= fd }
        del uobxs; del bobxs;
        uobxs,bobxs=uobxnew,bobxnew
    
    ufnum, bfnum = 0 , 0                    
    for obx in bobxs.keys():
        bobxs[obx]=bfnum
        bfnum+=K*K
    for obx in uobxs.keys():
        uobxs[obx]=ufnum
        ufnum+=K
    return uobxs,bobxs,ufnum,bfnum

def calObservexOn(tplist,texts,uobxs,bobxs,seqnum):
    '''speed up the feature calculation
      calculate the on feature functions ''' 
    uon=[]; bon=[]
    for sid in range(seqnum):  # for each traning sequence.
        sequon=[];seqbon=[]
        for lid in range(len(texts[sid])):
            luon=[];lbon=[]
            for ti,tp in enumerate(tplist):  # for each template line
                obx=expandOBX(texts,sid,lid,tp)
                #skey = str(ti)+":"+str(sid)+":"+str(lid)
                #obx=oball[skey]
                if tp[0][0]=="B":
                    fid=bobxs.get(obx)
                    #print fid
                    if fid!=None:
                        lbon.append(fid)
                if tp[0][0]=="U":
                    fid=uobxs.get(obx)
                    if fid!=None:
                        luon.append(fid)
            sequon.append(luon);seqbon.append(lbon)
        uon.append(sequon);bon.append(seqbon)
    return uon,bon

def calFSS(texts,oys,uon,bon,ufnum,bfnum,seqnum,K,y0):
    fss=numpy.zeros((ufnum+bfnum))
    fssb=fss[0:bfnum]
    fssu=fss[bfnum:]
    for i in range(seqnum):
        for li in range(len(texts[i])):
            for ao in uon[i][li]:
                fssu[ao+oys[i][li]]+=1.0
            for ao in bon[i][li]:
                if li==0:  # the first , yt-1=y0
                    fssb[ao+oys[i][li]*K+y0]+=1.0
                else:
                    fssb[ao+oys[i][li]*K+oys[i][li-1]]+=1.0
    return fss

def random_param(ufnum,bfnum):
    #theta=numpy.random.randn(ufnum+bfnum)
    theta=numpy.ones(ufnum+bfnum)
    return theta

def regularity(theta,type=0,sigma=1.0):
    if type == 0:
        regularity = 0
    elif type == 1:
        regularity = numpy.sum(numpy.abs(theta)) / sigma
    else:
        v = sigma ** 2
        v2 = v * 2
        regularity = numpy.sum(numpy.dot(theta,theta) )/ v2
    return regularity

def regularity_deriv(theta,type=0,sigma=1.0):
    if type == 0:
        regularity_deriv = 0
    elif type == 1:
        regularity_deriv = numpy.sign(theta) / sigma
    else:
        v = sigma ** 2
        regularity_deriv = theta / v
    return regularity_deriv


def logMarray(seqlen,auon,abon,K, thetau,thetab):
    ''' logMlist (n, K, K ) --> (sequence length, Yt, Yt-1)'''
    mlist=[]
    for li in range(seqlen):
        fv = numpy.zeros((K,K))
        for ao in auon[li]:
            fv+=thetau[ao:ao+K][:,numpy.newaxis]
        for ao in abon[li]:
            fv+=thetab[ao:ao+K*K].reshape((K,K))
        mlist.append(fv)
    
    for i in range(0,K):  # set the energe function for ~y(0) to be -inf.
        mlist[0][i][1:]= - float("inf")
    #print "mlist:",mlist
    return mlist      

def logAlphas(Mlist):
    logalpha = Mlist[0][:,0] # alpha(1)
    logalphas = [logalpha]
    for logM in Mlist[1:]:
        logalpha = logdotexp_vec_mat(logalpha, logM)
        logalphas.append(logalpha)
    #print "logalphas:",logalphas
    return logalphas
    
def logBetas(Mlist):
    logbeta = numpy.zeros_like(Mlist[-1][:, 0])
    logbetas = [logbeta]
    for logM in Mlist[-1:0:-1]:
        logbeta = logdotexp_mat_vec(logM, logbeta)
        logbetas.append(logbeta)
    #print "logbeta:",logbetas[::-1]
    return logbetas[::-1]

def likelihood(seqlens,fss,uon,bon,theta,seqnum,K,ufnum,bfnum,regtype,sigma):
    global _gradient
    grad = numpy.array(fss,copy=True)  # data distribuition
    likelihood = numpy.dot(fss,theta)
    gradb=grad[0:bfnum]
    gradu=grad[bfnum:]
    thetab=theta[0:bfnum]
    thetau=theta[bfnum:]
    #likelihood = numpy.dot(fss,theta)
    for si in range(seqnum):
        #logMlist = logMarray(seqlens[si],si,uon,bon,K,thetau,thetab)
        logMlist = logMarray(seqlens[si],uon[si],bon[si],K,thetau,thetab)
        logalphas = logAlphas(logMlist)
        logbetas = logBetas(logMlist)
        logZ = logsumexp(logalphas[-1])
        likelihood -= logZ
        expect = numpy.zeros((K,K))
        for i in range(len(logMlist)):
            if i == 0:
                expect = numpy.exp(logMlist[0] + logbetas[i][:,numpy.newaxis] - logZ)
            elif i < len(logMlist) :
                expect = numpy.exp(logMlist[i] + logalphas[i-1][numpy.newaxis,: ] + logbetas[i][:,numpy.newaxis] - logZ)
            #print "expect t:",i, "expect: ", expect
            p_yi=numpy.sum(expect,axis=1)
            # minus the parameter distribuition
            for ao in uon[si][i]:
                gradu[ao:ao+K] -= p_yi
            for ao in bon[si][i]:
                gradb[ao:ao+K*K] -= expect.reshape((K*K))
    grad -= regularity_deriv(theta,regtype,sigma)
    _gradient = grad
    return likelihood - regularity(theta,regtype,sigma)

def gradient_likelihood(theta):    # this is a dummy function
    global _gradient
    return _gradient

def saveModel(bfnum,ufnum,tlist,obydic,uobxs,bobxs,theta,modelfile):
#    import cPickle as pickle
#    with open(modelfile, 'wb') as f:
#        pickle.dump([bfnum,ufnum,tlist,obydic,uobxs,bobxs,theta], f)
    print("Model------------------")
    print(bfnum,ufnum,tlist,obydic,uobxs,bobxs,theta)



def outputFile(texts,oys,maxys,y2label,resfile):
    if resfile=="":   #  don't need to write to file.
        return 0  
    fo = codecs.open(resfile, "w")
    for si in range(len(oys)):
        for li in range(len(oys[si])):
            strt=""
            for x in texts[si][li]:
                strt += x +" "
            strt += y2label[oys[si][li]]+" "
            strt += y2label[maxys[si][li]]
            strt += "\n"
            fo.write(strt)
        fo.write(" \n")
    fo.close()
    return 0

def loadModel(modelFile):
    import cPickle as pickle
    if not os.path.isfile(modelFile):
        print ("Error: model file does not Exist!")
        return -1
    with open(modelFile, 'rb') as f:
        bfnum,ufnum,tlist,obydic,uobxs,bobxs,theta = pickle.load(f)
    K=len(obydic)
    y2label = dict([(obydic[key],key) for key in obydic.keys()])
    return bfnum,ufnum,tlist,obydic,uobxs,bobxs,theta,K,y2label

def tagging(seqlens,uon,bon,theta,seqnum,K,ufnum,bfnum):
    thetab=theta[0:bfnum]
    thetau=theta[bfnum:]
    #likelihood = numpy.dot(fss,theta)
    maxys=[]
    for si in range(seqnum):
        logMlist = logMarray(seqlens[si],uon[si],bon[si], K, thetau,thetab)
        #logalphas = logAlphas(logMlist)
        #logZ = logsumexp(logalphas[-1])
        maxalpha=numpy.zeros((len(logMlist),K))
        my=[]  ;  maxilist=[]
        seqlen=len(logMlist)
        for i in range(seqlen):
            if i == 0:
                maxalpha[i] = logMlist[0][:,0]
                #print maxalpha[0]
            elif i < seqlen :
                at = logMlist[i]+maxalpha[i-1]
                maxalpha[i] = at.max(axis=1)
                #print maxalpha[i]
                maxilist.append(at.argmax(axis=1))
        ty=maxalpha[-1].argmax()
        my.append(ty)
        for a in (reversed(maxilist)):
            my.append(a[ty])
            ty=a[ty]
        maxys.append(my[::-1])
    return maxys

def checkTagging(maxys,oys):
    tc=0 ; te=0;
    #print maxys
    #print oy
    for si in range(len(oys)):
        for li in range(len(oys[si])):
            if oys[si][li]==maxys[si][li]:
                tc += 1
            else:
                te +=1
    print ("Note: If Y is useless, correct rate is also useless.")
    print ("correct:",tc,"error:",te," correct rate:",float(tc)/(tc+te))


def train(datafile,tpltfile,modelfile,regtype=2,sigma=1.0):
    import time 
    start_time = time.time()
    if not os.path.isfile(tpltfile):
        print ("Can't find the template file!")
        return -1
    tplist=readTemplate(tpltfile)    #读取模板文件
    print (tplist)
    
    if not os.path.isfile(datafile):
        print ("Data file doesn't exist!")
        return -1
    texts,seqlens,oys,seqnum,K,obydic,y2label=readData(datafile) #读取训练数据
    print( seqlens )
    
    uobxs,bobxs,ufnum,bfnum=processFeatures(tplist,texts,seqnum,K)
    fnum=ufnum+bfnum
    print( "B features:",bfnum,"U features:",ufnum, "total num:",fnum)
    print( "training sequence number:",seqnum)
    print( "start to calculate ON feature.  ", time.time() - start_time, "seconds. \n ")
    uon,bon = calObservexOn(tplist,texts,uobxs,bobxs,seqnum)

    #print  "ubon size:", sys.getsizeof(uon)
    #print  "uobxs size:", sys.getsizeof(uobxs)
    #print  "texts size:", sys.getsizeof(texts)
    print ("start to calculate data distribuition. ", time.time() - start_time, "seconds. \n ")
#    del uobxs
#    del bobxs
    
    y0=0
    fss=calFSS(texts,oys,uon,bon,ufnum,bfnum,seqnum,K,y0)
    del texts    
    del oys
    
#    import cPickle as pickle
#    with open("dump", 'wb') as f:
#        pickle.dump([uon], f)
        
    print ("start to learn distribuition. ", time.time() - start_time, "seconds. \n " )

    #return
    
    from scipy import optimize
    theta=random_param(ufnum,bfnum)
    likeli = lambda x:-likelihood(seqlens,fss,uon,bon,x,seqnum,K,ufnum,bfnum,regtype,sigma)
    likelihood_deriv = lambda x:-gradient_likelihood(x)
    theta,fobj,dtemp = optimize.fmin_l_bfgs_b(likeli,theta, 
            fprime=likelihood_deriv , disp=1, factr=1e12)
    print(dtemp)

    saveModel(bfnum,ufnum,tplist,obydic,uobxs,bobxs,theta,modelfile)
    print( "Training finished in ", time.time() - start_time, "seconds. \n ")
    
    
#------------------------------------------------------    
    K=len(obydic)
    y2label = dict([(obydic[key],key) for key in obydic.keys()])
    fnum=ufnum+bfnum
    if fnum==0:
        print ("ERROR: Load the model file failed!")
        return -1
    texts,seqlens,oys,seqnum,t1,obydictmp,y2ltmp=readData('test.data')
    if seqnum==0 or len(obydic)==0:
        print ("ERROR: Read data file failed!")
        return -1
    # change the oys to be concist with model
    for i in range(len(oys)):
        for j in range(len(oys[i])):
            slabel=y2ltmp[oys[i][j]]
            if slabel in obydic:  # some
                oys[i][j] = obydic[y2ltmp[oys[i][j]]]
            else:
                oys[i][j] = 0
    
    print ("B features:",bfnum,"U features:",ufnum, "total num:",fnum)
    print ("Prediction sequence number:",seqnum)
    uon,bon = calObservexOn(tplist,texts,uobxs,bobxs,seqnum)
    maxys = tagging(seqlens,uon,bon,theta,seqnum,K,ufnum,bfnum)
    checkTagging(maxys,oys)
    print( "Write max(y) to file:",'result.txt')
    outputFile(texts,oys,maxys,y2label,'result.txt')
    print ("Test finished in ", time.time() - start_time, "seconds. \n ")





def crfpredict(datafile,modelfile,resfile=""):
    import time 
    start_time = time.time()
    '''read all the data'''
    bfnum,ufnum,tplist,obydic,uobxs,bobxs,theta,K,y2label=loadModel(modelfile)
    fnum=ufnum+bfnum
    if fnum==0:
        print ("ERROR: Load the model file failed!")
        return -1
    texts,seqlens,oys,seqnum,t1,obydictmp,y2ltmp=readData(datafile)
    if seqnum==0 or len(obydic)==0:
        print ("ERROR: Read data file failed!")
        return -1
    # change the oys to be concist with model
    for i in range(len(oys)):
        for j in range(len(oys[i])):
            slabel=y2ltmp[oys[i][j]]
            if obydic.has_key(slabel):  # some
                oys[i][j] = obydic[y2ltmp[oys[i][j]]]
            else:
                oys[i][j] = 0
    
    print ("B features:",bfnum,"U features:",ufnum, "total num:",fnum)
    print ("Prediction sequence number:",seqnum)
    uon,bon = calObservexOn(tplist,texts,uobxs,bobxs,seqnum)
    maxys = tagging(seqlens,uon,bon,theta,seqnum,K,ufnum,bfnum)
    checkTagging(maxys,oys)
    print( "Write max(y) to file:",resfile)
    outputFile(texts,oys,maxys,y2label,resfile)
    print ("Test finished in ", time.time() - start_time, "seconds. \n ")


train("train.data","templatechunk","model")
#crfpredict("testchunk.data","model","res.txt")
#crfpredict("tr1.utf8.txt","model","res.txt")
