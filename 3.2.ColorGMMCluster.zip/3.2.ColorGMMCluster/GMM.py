import numpy as np
import matplotlib.pyplot as plt 
import cv2
import glob, os
from sklearn.mixture import GaussianMixture

'''
from sklearn.datasets.samples_generator import make_blobs 
X, y_true = make_blobs(n_samples=400, centers=4, 
cluster_std=0.60, random_state=0) 

gmm = GaussianMixture(n_components=4).fit(X) 
labels = gmm.predict(X) 
plt.scatter(X[:, 0], X[:, 1], c=labels, s=40, cmap='viridis'); 
           
'''

def getRGBS(img):
	image = cv2.cvtColor(img,cv2.COLOR_BGR2RGB)
	# the figure and the flattened feature vector
	chans = cv2.split(image)
	colors = ("r", "g", "b")
	features = []
	featuresSobel = []
	for (chan, color) in zip(chans, colors):
		hist = cv2.calcHist([chan], [0], None, [8], [0, 256])
		hist = hist/hist.sum()
		features.extend(hist[:,0].tolist())
	features.extend(featuresSobel)

	Grayscale = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
	histG = cv2.calcHist([chan], [0], None, [8], [0, 256])
	histG = histG / histG.sum()
	features.extend(histG[:,0].tolist())

	grad_x = np.abs(cv2.Sobel(Grayscale, cv2.CV_16S, 1, 0, ksize = 3, scale = 1, delta = 0, borderType = cv2.BORDER_DEFAULT))
	grad_y = np.abs(cv2.Sobel(Grayscale, cv2.CV_16S, 0, 1, ksize = 3, scale = 1, delta = 0, borderType = cv2.BORDER_DEFAULT))
	abs_grad_x = cv2.convertScaleAbs(grad_x)
	abs_grad_y = cv2.convertScaleAbs(grad_y)
	dst = cv2.addWeighted(abs_grad_x,0.5,abs_grad_y,0.5,0)
	histSobel = cv2.calcHist([dst], [0], None, [8], [0, 256])
	histSobel = histSobel / histSobel.sum()
	features.extend(histSobel[:,0].tolist())

	hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
	chans = cv2.split(hsv)
	S = chans[1]
	hist2 = cv2.calcHist([S], [0], None, [8], [0, 256])
	hist2 = hist2/hist2.sum()
	features.extend(hist2[:,0].tolist()) 

	return features


def blockshaped(arr):
    blocks = []    
    blocks.append(arr[0:arr.shape[0],0:arr.shape[1]/2])
    blocks.append(arr[0:arr.shape[0],arr.shape[1]/2:-1])
    return blocks



def featureExtraction(img):
    blocks = blockshaped(img)    
    fColor1 = getRGBS(blocks[0]);    
    fColor2 = getRGBS(blocks[1]);     
    fv = fColor1 + fColor2
    #fNames = namesColor + namesColor
    return fv



def getFeaturesFromFile(fileName):
    img = cv2.imread(fileName)
#    img = cv2.imread(fileName, cv2.CV_LOAD_IMAGE_COLOR)    # read image
    F = featureExtraction(img)            # feature extraction
    return F

def getFeaturesFromDir(dirName):
    types = ('*.jpg', '*.JPG', '*.png')    
    imageFilesList = []
    for files in types:
        imageFilesList.extend(glob.glob(os.path.join(dirName, files)))
    imageFilesList = sorted(imageFilesList)
    print(imageFilesList)
    Features = []
    f_in = open('feat',"w")
    for i, imFile in enumerate(imageFilesList):    
        #print( "{0:.1f}".format(100.0 * float(i) / len(imageFilesList)))
        F = getFeaturesFromFile(imFile)
        #print( F)
        f_in.write(str(F) + '\n')
        Features.append(F)

    Features = np.matrix(Features)
    return Features


FM= getFeaturesFromDir('image')
gmm = GaussianMixture(n_components=5).fit(FM) 
labels = gmm.predict(FM) 
print(labels)
x=np.arange(0, 32, 1)
plt.plot(x,labels)

