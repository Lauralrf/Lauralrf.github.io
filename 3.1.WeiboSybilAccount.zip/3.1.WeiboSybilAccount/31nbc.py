# -*- coding: utf-8 -*-
"""
Created on Thu Jun 15 22:31:09 2017

@author: Administrator
"""

from sklearn import datasets,cross_validation,naive_bayes
import numpy as np
import matplotlib.pyplot as plt

def show_digitals():
    digitals = datasets.load_digits()
    fig = plt.figure()
    print("vector from images 0:",digitals.data[0])
    for i in range(25):
        ax = fig.add_subplot(5,5,i+1)
        ax.imshow(digitals.images[i],cmap=plt.cm.gray_r,interpolation='nearest')
    plt.show()

def load_data():
    digitals = datasets.load_digits()
    return cross_validation.train_test_split(digitals.data,digitals.target,test_size=0.25,random_state=0)
    
    
def GaussianNB(*data):
    X_train,X_test,y_train,y_test = data
    cls = naive_bayes.MultinomialNB()   #GaussianNB()
    cls.fit(X_train,y_train)
    print('Training Score:%.2f' %cls.score(X_train,y_train))
    print('Testing Score:%.2f' %cls.score(X_test,y_test))
  
show_digitals()
X_train,X_test,y_train,y_test = load_data()
GaussianNB(X_train,X_test,y_train,y_test)