/*this code achieves training of LDA by using synchronous BP algorithm*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <assert.h>
#include <mex.h>
#include "topiclib.cpp"

//sBP(W, D, nzmax, Titer, Ktopic, ALPHA, BETA, ele, row, col, phi, theta, mu);
void sBP(int W, int D, int nzmax, int Titer, int Ktopic, double ALPHA, double BETA, double *ele, mwIndex *row, mwIndex *col,
        double *phi, double *theta, double *mu)
{
    int wt, dt, jt, kt, iter;
    double xt, xtot = 0.0;
    double perp, mutot;
    double wbeta = (double) (W*BETA);
    double kalpha = (double) (Ktopic*ALPHA);
    
    /*allocation*/
    double *kw_mu = (double*)mxCalloc(D, sizeof(double));
    double *wd_mu = (double*)mxCalloc(Ktopic, sizeof(double));
    
    /* random initialization */
    for (dt=0; dt<D; dt++) {
        for (jt=(int)col[dt]; jt<col[dt + 1]; jt++) {
            wt = (int) row[jt];
            xt = ele[jt];
            xtot += xt;
            kw_mu[dt] += xt;
            // pick a random kt 0..Ktopic-1
            kt = (int) (Ktopic*drand());
            mu[jt*Ktopic + kt] = (double) 1; // assign this word token to this kt
            phi[wt*Ktopic + kt] += xt; // increment phi count matrix
            theta[dt*Ktopic + kt] += xt; // increment theta count matrix
            wd_mu[kt] += xt; // increment wd_mu matrix
        }
    }
    
    for (iter=0; iter<Titer; iter++) {
        
        if (((iter % 10)==0) && (iter != 0)) {
            /* calculate perplexity */
            perp = (double) 0;
            for (dt=0; dt<D; dt++) {
                for (jt=(int)col[dt]; jt<col[dt + 1]; jt++) {
                    wt = (int) row[jt];
                    xt = ele[jt];
                    mutot = (double) 0;
                    for (kt=0; kt<Ktopic; kt++) {
                        mutot += ((double) phi[wt*Ktopic + kt] + (double) BETA)/
                                ((double) wd_mu[kt] + (double) wbeta)*
                                ((double) theta[dt*Ktopic + kt] + (double) ALPHA)/
                                ((double) kw_mu[dt] + (double) kalpha);
                    }
                    perp -= (log(mutot) * xt);
                }
            }
            mexPrintf("\tIteration %d of %d:\t%f\n", iter, Titer, exp(perp/xtot));
            mexEvalString("drawnow;");
        }
        
        /* passing message mu */
        for (dt=0; dt<D; dt++) {
            for (jt=(int)col[dt]; jt<col[dt + 1]; jt++) {
                wt = (int) row[jt];
                xt = ele[jt];
                mutot = (double) 0;
                for (kt=0; kt<Ktopic; kt++) {
                    mu[jt*Ktopic + kt] = ((double) phi[wt*Ktopic + kt] - (double) xt*mu[jt*Ktopic + kt] + (double) BETA)/
                            ((double) wd_mu[kt] - (double) xt*mu[jt*Ktopic + kt] + (double) wbeta)*
                            ((double) theta[dt*Ktopic + kt] - (double) xt*mu[jt*Ktopic + kt] + (double) ALPHA);
                    mutot += mu[jt*Ktopic + kt];
                }
                for (kt=0; kt<Ktopic; kt++) {
                    mu[jt*Ktopic + kt] /= mutot;
                }
            }
        }
        
        /* clear phi, theta, and wd_mu */
        for (jt=0; jt<Ktopic*W; jt++) phi[jt] = (double) 0;
        for (jt=0; jt<Ktopic*D; jt++) theta[jt] = (double) 0;
        for (kt=0; kt<Ktopic; kt++) wd_mu[kt] = (double) 0;
        
        /* update theta, phi and wd_mu using message mu */
        for (dt=0; dt<D; dt++) {
            for (jt=(int)col[dt]; jt<col[dt + 1]; jt++) {
                wt = (int) row[jt];
                xt = ele[jt];
                for (kt = 0; kt < Ktopic; kt++) {
                    phi[wt*Ktopic + kt] += xt*mu[jt*Ktopic + kt]; 
                    theta[dt*Ktopic + kt] += xt*mu[jt*Ktopic + kt]; 
                    wd_mu[kt] += xt*mu[jt*Ktopic + kt]; 
                }
            }
        }
    }
}

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    double *mu, *phi, *theta, *ele;
    double ALPHA, BETA;
    mwIndex *row, *col;
    int W, D, Titer, Ktopic, SEED, nzmax;
    
    /* read sparse array WD */
    if (mxIsDouble(prhs[0]) != 1) mexErrMsgTxt("WD must be a double precision matrix");
    ele = mxGetPr(prhs[0]);
    row = mxGetIr(prhs[0]);
    col = mxGetJc(prhs[0]);
    nzmax = (int) mxGetNzmax(prhs[0]);
    W = (int) mxGetM(prhs[0]);
    D = (int) mxGetN(prhs[0]);
    
    Ktopic = (int) mxGetScalar(prhs[1]);
    if (Ktopic<=0) mexErrMsgTxt("Number of topics must be greater than zero");
    
    Titer = (int) mxGetScalar(prhs[2]);
    if (Titer<0) mexErrMsgTxt("Number of iterations must be positive");
    
    ALPHA = (double) mxGetScalar(prhs[3]);
    if (ALPHA<0) mexErrMsgTxt("ALPHA must be greater than zero");
    
    BETA = (double) mxGetScalar(prhs[4]);
    if (BETA<0) mexErrMsgTxt("BETA must be greater than zero");
    
    SEED = (int) mxGetScalar(prhs[5]);
    
    /* seeding */
    seedMT(1 + SEED*2); // seeding only works on uneven numbers
    
    /* allocate memory */
    mu = (double*)mxCalloc(Ktopic*nzmax, sizeof(double));
    theta = (double*)mxCalloc(Ktopic*D, sizeof(double));
    phi = (double*)mxCalloc(Ktopic*W, sizeof(double));
    
    /* run the learning algorithm */
    sBP(W, D, nzmax, Titer, Ktopic, ALPHA, BETA, ele, row, col, phi, theta, mu);
    
    /* output */
    plhs[0] = mxCreateDoubleMatrix(Ktopic, W, mxREAL);
    mxSetPr(plhs[0], phi);
    
    plhs[1] = mxCreateDoubleMatrix(Ktopic, D, mxREAL );
    mxSetPr(plhs[1], theta);
    
    plhs[2] = mxCreateDoubleMatrix(Ktopic, nzmax, mxREAL);
    mxSetPr(plhs[2], mu);
}
