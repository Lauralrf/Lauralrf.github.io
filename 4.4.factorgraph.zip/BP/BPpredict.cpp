/*this project is to get the predictive perplexity of unseen dataset
by training parameters:theta and phi 1000 iterations respectively.
The whole process can be divided into three steps:
training:
1.training theta and phi on training dataset for about 1000 iterations;
predict:
2.training theta using the phi from the trained phi fixed for about 1000 iterations;
3.calculating the predictive perplexity using the theta and phi by the last two steps of parameters' training
*/

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <math.h>
#include <string>
#include <mex.h>
#include "topiclib.cpp"


/*first training for phi and theta(get phi last)*/
void training(int T, int D, int W, int topics, int nzmax, double ALPHA, double BETA,
              double *ele, mwIndex *row, mwIndex *col, double *phi)
{
    /*temporary variations*/
    int dt, wt, kt, jt, iter;
    double xt, mu_temp, temp, x_total = 0;
    double kalpha = topics*ALPHA;
    double wbeta = W*BETA;

    double *theta = (double*)mxCalloc(D*topics, sizeof(double));
    double *mu = (double*)mxCalloc(topics*nzmax, sizeof(double));
    double *kw_mu = (double*)mxCalloc(D, sizeof(double));
    double *wd_mu = (double*)mxCalloc(topics, sizeof(double));

    /*initialize*/
    for(dt = 0; dt < D; dt++){
        for(jt = (int)col[dt]; jt < col[dt+1]; jt++){
            wt = (int)row[jt];
            xt = ele[jt];
            x_total += xt;
            kw_mu[dt] += xt;
            //pick a topic randomly for initialization
            kt = (int)(topics*drand());
            mu[kt*nzmax + jt] = (double)1;
            theta[dt*topics + kt] += (double)xt;
            phi[wt*topics + kt] += (double)xt;
            wd_mu[kt] += (double)xt;
        }
    }

    /*message update*/
    for(iter = 0; iter < T; iter++){
        for(dt = 0; dt < D; dt++){
            for(jt = (int)col[dt]; jt < col[dt+1]; jt++){
                wt = (int)row[jt];
                xt = ele[jt];
                mu_temp = 0;
                for(kt = 0;kt < topics; kt++){
                    /*the calculation is different from the formulation on paper*/
                    mu[kt*nzmax + jt] = ((double)theta[dt*topics + kt] - (double)xt*mu[kt*nzmax + jt] + (double)ALPHA)/((double)wd_mu[kt] - (double)xt*mu[kt*nzmax + jt] + wbeta)
                    *((double)phi[wt*topics + kt] - (double)xt*mu[kt*nzmax + jt] + (double)BETA);
                    mu_temp += mu[kt*nzmax + jt];
                }
                /*normalization*/
                for(kt = 0; kt < topics; kt++){
                    mu[kt*nzmax + jt] = mu[kt*nzmax + jt]/mu_temp;
                }
            }
        }

        /*message passing and update for summation*/
        for(kt = 0; kt < topics; kt++){
            for(dt = 0; dt < D; dt++){
                theta[dt*topics + kt] = (double)0;
            }
            for(wt = 0; wt < W; wt++){
                phi[wt*topics + kt] = (double)0;
            }
            wd_mu[kt] = (double)0;
        }

        for(dt = 0; dt < D; dt++){
            for(jt = (int)col[dt]; jt < col[dt+1]; jt++){
                wt = (int)row[jt];
                xt = ele[jt];
                for(kt = 0; kt < topics; kt++){
                    temp = (double)xt*mu[kt*nzmax + jt];
                    theta[dt*topics + kt] += temp;
                    phi[wt*topics + kt] += temp;
                    wd_mu[kt] += temp;
                }
            }
        }
    }

    mxFree(mu);
    mxFree(theta);
    mxFree(kw_mu);
    mxFree(wd_mu);
}


/*second prediction:calculate theta when phi fixed*/
void thetaTraining_Predicting(int T, int D, int W, int topics, int nzmax, double ALPHA, double BETA,
                              double *ele, mwIndex *row, mwIndex *col, double *phi, double *perplexity)
{
    /*temporary variations*/
    int wt, dt, kt, jt, iter;
    double xt, pert, mu_temp, temp;
    double x_total = 0, kalpha = topics*ALPHA, wbeta = W*BETA;

    double *theta = (double*)mxCalloc(D*topics, sizeof(double));
    double *mu = (double*)mxCalloc(topics*nzmax, sizeof(double));
    double *kw_mu = (double*)mxCalloc(D, sizeof(double));
    double *wd_mu = (double*)mxCalloc(topics, sizeof(double));

    /*initialization*/
    for(wt = 0; wt < W; wt++){//for phi fixed
        for(kt = 0; kt < topics; kt++){
            wd_mu[kt] += phi[wt*topics + kt];
        }
    }

    for(dt = 0; dt < D; dt++){
        for(jt = (int)col[dt]; jt < col[dt+1]; jt++){
            wt = (int)row[jt];
            xt = ele[jt];
            x_total += xt;
            kw_mu[dt] += xt;
            //pick topic for initialization randomly
            kt = (int)(topics*drand());;
            mu[kt*nzmax + jt] = (double)1;
            theta[dt*topics + kt] += xt;//phi fixed
        }
    }

    for(iter = 0; iter < T; iter++){
        if( iter == T-10){
            /*calculate the perplexity after theta's adoptive training on test dataset(consider dimensions)*/
            perplexity[0] = (double)0;
            for(dt = 0;dt < D; dt++){
                for(jt = (int)col[dt]; jt < col[dt+1]; jt++){
                    wt = (int)row[jt];
                    xt = ele[jt];
                    pert = (double)0;
                    for(kt = 0; kt < topics; kt++){
                        pert += ((double)theta[dt*topics + kt] + (double)ALPHA)/((double)kw_mu[dt] + kalpha)
                                *((double)phi[wt*topics + kt] + (double)BETA)/((double)wd_mu[kt] + wbeta);
                     }
                    perplexity[0] -= (xt*log(pert));
                }
            }
            perplexity[0] = exp(perplexity[0]/x_total);
            mexPrintf("The final predictive perplexity with %d topics:%f\n", topics, perplexity[0]);
        }
        
        /*message update*/
        for(dt = 0; dt < D; dt++){
            for(jt = (int)col[dt]; jt < col[dt+1]; jt++){
                wt = (int)row[jt];
                xt = ele[jt];
                mu_temp = 0.0;
                for(kt = 0; kt < topics; kt++){
                    /*the calculation is different from the formulation on paper*/
                    mu[kt*nzmax + jt] = ((double)theta[dt*topics + kt] - (double)xt*mu[kt*nzmax + jt] + (double)ALPHA)/((double)wd_mu[kt] + wbeta)
                                 *((double)phi[wt*topics + kt] + (double)BETA);
                    mu_temp += mu[kt*nzmax + jt];
                }
                /*normalization*/
                for(kt = 0; kt < topics; kt++){
                    mu[kt*nzmax + jt] = mu[kt*nzmax + jt]/mu_temp;
                }
            }
        }
        /*message passing*/
        for(dt = 0; dt < D; dt++){
            for(kt = 0; kt < topics; kt++){
                theta[dt*topics + kt] = (double)0;
            }
        }

        for(dt = 0; dt < D; dt++){
            for(jt = (int)col[dt]; jt < col[dt+1]; jt++){
                xt = ele[jt];
                for(kt = 0; kt < topics; kt++){
                    theta[dt*topics + kt] += (double)xt*mu[kt*nzmax + jt];
                }
            }
        }
    }
    
    mxFree(theta);
    mxFree(mu);
    mxFree(kw_mu);
    mxFree(wd_mu);
}

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    /*variations' definition*/
    //t for training, s for test
    double *phi, *ele_t, *ele_s;
    double ALPHA, BETA;
    double *perplexity;
    mwIndex *row_t, *row_s, *col_t, *col_s;
    int Titer, Ktopic, W, SEED, i, j;
    int D_t, nzmax_t;
    int D_s, nzmax_s;

    /*check the input*/
    //training dataset
    if(mxIsDouble(prhs[0]) != 1) mexErrMsgTxt("Training dataset must be a double matrix!");

    ele_t = mxGetPr(prhs[0]);
    row_t = mxGetIr(prhs[0]);
    col_t = mxGetJc(prhs[0]);
    nzmax_t = (int)mxGetNzmax(prhs[0]);
    D_t = (int)mxGetN(prhs[0]);
    W = (int)mxGetM(prhs[0]);

    if(mxIsDouble(prhs[1]) != 1) mexErrMsgTxt("Test dataset must be a double matrix!");

    ele_s = mxGetPr(prhs[1]);
    row_s = mxGetIr(prhs[1]);
    col_s = mxGetJc(prhs[1]);
    nzmax_s = (int)mxGetNzmax(prhs[1]);
    D_s = (int)mxGetN(prhs[1]);
    W = (int)mxGetM(prhs[1]);

    Ktopic = (int)mxGetScalar(prhs[2]);
    if(Ktopic <= 0) mexErrMsgTxt("Number of topics must be greater than 0!");

    Titer = (int)mxGetScalar(prhs[3]);
    if(Titer < 0 ) mexErrMsgTxt("Number of iteration must be positive!");

    ALPHA = (double)mxGetScalar(prhs[4]);
    if(ALPHA < 0) mexErrMsgTxt("ALPHA must be greater then 0!");

    BETA = (double)mxGetScalar(prhs[5]);
    if(BETA < 0) mexErrMsgTxt("BETA must be greater then 0!");

    SEED = (int)mxGetScalar(prhs[6]);

    /*processor*/
    seedMT(1 + SEED*2);//seeding only works on odd numbers

    phi = (double *) mxCalloc(W*Ktopic, sizeof(double));

    perplexity = (double *) mxCalloc(1, sizeof(double));

    training(Titer, D_t, W, Ktopic, nzmax_t, ALPHA, BETA, ele_t, row_t, col_t, phi);
    thetaTraining_Predicting(Titer, D_s, W, Ktopic, nzmax_s, ALPHA, BETA, ele_s, row_s, col_s, phi, perplexity);

    plhs[0] = mxCreateDoubleMatrix(1, 1, mxREAL);
    mxSetPr(plhs[0], perplexity);
}