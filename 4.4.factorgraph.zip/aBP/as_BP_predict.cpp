/*This project is to predict the unseen documents' topic configuration
 and calculate the predictive perplexity.
 the processing can be divided into two parts:
 1.training theta and phi on the training dataset
 2.adoting the phi's dimension on test data, 
   and calculating the predictive perplexity at the same time.
 the passing method of messages is asynchronous.*/

/*link files*/
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h> //???
#include <math.h>
#include <mex.h>
#include "topiclib.cpp"

/*training on the training dataset*/
void as_training(int W, int D_t, int Ktopic, int Titer, int nzmax_t, double ALPHA, double BETA,
                 mwIndex *row_t, mwIndex *col_t, double *ele_t, double *phi)
{
   /*variable-definition*/
   int dt, wt, kt, jt, iter;
   double xt, x_total = 0.0, mu_temp = 0.0, perplexity;
   double kalpha = (double)Ktopic*ALPHA;
   double wbeta = (double)W*BETA;
   double *theta, *mu, *kw_mu, *wd_mu;
   
   /*allocating memory*/
   theta = (double*)mxCalloc(D_t*Ktopic, sizeof(double));   
   mu = (double*)mxCalloc(Ktopic*nzmax_t, sizeof(double));
   kw_mu = (double*)mxCalloc(D_t, sizeof(double));
   wd_mu = (double*)mxCalloc(Ktopic, sizeof(double));
   
   /*initialization*/
   for (dt = 0; dt < D_t; dt++)
   {
       for (jt = (int)col_t[dt]; jt < col_t[dt + 1]; jt++)
       {
           xt = ele_t[jt];
           wt = (int)row_t[jt];
           x_total += xt;
           kw_mu[dt] += xt;
           /*pick up topic of wd randomly*/
           kt = (int)(Ktopic*drand());
           mu[kt*nzmax_t + jt] = (double)1;
           theta[dt*Ktopic + kt] += xt;
           phi[wt*Ktopic + kt] += xt;
           wd_mu[kt] += xt;
       }
   }
   
   /*start iterating and message updating*/
   for (iter = 0; iter < Titer; iter++)
   {
       /*calculating perplexity*/
       if ((iter%10 == 0)&&(iter != 0))
        {
            perplexity = 0.0;
            for (dt = 0; dt < D_t; dt++)
            {
                for (jt = (int)col_t[dt]; jt < col_t[dt + 1]; jt++)
                {
                    wt = (int)row_t[jt];
                    xt = ele_t[jt];
                    mu_temp = 0.0;
                    for (kt = 0; kt < Ktopic; kt++)
                    {
                        mu_temp += ((double)theta[dt*Ktopic + kt] + ALPHA)/((double)kw_mu[dt] + kalpha)
                                *((double)phi[wt*Ktopic + kt] + BETA)/((double)wd_mu[kt] + wbeta);
                    }
                    perplexity -= (xt*log(mu_temp));
                }
            }
            perplexity = exp(perplexity/x_total);
            mexPrintf("Perplexity of %d of Iteration %d is: %f\n", iter, Titer, perplexity);
            mexEvalString("drawnow;"); 
        }
       /*message updating*/
       for (dt = 0; dt <D_t; dt++)
       {
           for (jt = (int)col_t[dt]; jt < col_t[dt + 1]; jt++)
           {
               xt = ele_t[jt];
               wt = (int)row_t[jt];
               mu_temp = 0.0;
               for (kt = 0; kt < Ktopic; kt++)
               {
                   /*subscrapting the last message of site dwk*/
                   theta[dt*Ktopic + kt] = theta[dt*Ktopic + kt] - (double)xt*mu[kt*nzmax_t + jt];
                   phi[wt*Ktopic + kt] = phi[wt*Ktopic + kt] - (double)xt*mu[kt*nzmax_t + jt];
                   wd_mu[kt] = wd_mu[kt] - (double)xt*mu[kt*nzmax_t + jt];
                   /*calculating the new message on site dwk*/
                   mu[kt*nzmax_t + jt] = ((double)theta[dt*Ktopic + kt] + ALPHA)/((double)wd_mu[kt] + wbeta)
                                         *((double)phi[wt*Ktopic + kt] + BETA);
                   mu_temp += mu[kt*nzmax_t + jt];
               }
               for (kt = 0; kt < Ktopic; kt++)
               {
                   /*updating*/
                   mu[kt*nzmax_t + jt] = mu[kt*nzmax_t + jt]/mu_temp;
                   theta[dt*Ktopic + kt] = theta[dt*Ktopic + kt] + (double)xt*mu[kt*nzmax_t + jt];
                   phi[wt*Ktopic + kt] = phi[wt*Ktopic + kt] + (double)xt*mu[kt*nzmax_t + jt];
                   wd_mu[kt] = wd_mu[kt] + (double)xt*mu[kt*nzmax_t + jt];
               }
           }
       }
   }
   /*after iterating,free the memory that allocated before*/
   mxFree(theta);
   mxFree(mu);
   mxFree(kw_mu);
   mxFree(wd_mu);
}

/*adoting and calculating the predictive perplexity*/
void as_predicting(int W, int D_s, int Ktopic, int Titer, int nzmax_s, double ALPHA, double BETA,
                   mwIndex *row_s, mwIndex *col_s, double *ele_s, double *phi,double *perplexity)
{
    /*variable-definition*/
    int dt, wt, kt, jt, iter;
    double xt, x_total = 0.0, mu_temp = 0, perp = 0.0;
    double kalpha = (double)Ktopic*ALPHA;
    double wbeta = (double)W*BETA;
    double *theta, *mu, *kw_mu, *wd_mu;
    
    /*allocating memory*/
    theta = (double*)mxCalloc(D_s*Ktopic, sizeof(double));   
    mu = (double*)mxCalloc(Ktopic*nzmax_s, sizeof(double));
    kw_mu = (double*)mxCalloc(D_s, sizeof(double));
    wd_mu = (double*)mxCalloc(Ktopic, sizeof(double));
    
    /*initialization when phi is fixed*/
    for (wt = 0; wt < W; wt++)
    {
        for (kt = 0; kt < Ktopic; kt++)
        {
            wd_mu[kt] += phi[wt*Ktopic + kt];
        }
    }
    
    for (dt = 0; dt < D_s; dt++)
    {
        for (jt = (int)col_s[dt]; jt < col_s[dt + 1]; jt++)
        {
            wt = (int)row_s[jt];
            xt = ele_s[jt];
            x_total += xt;
            kw_mu[dt] += xt;
            /*pick up topic randomly*/
            kt = (int)(Ktopic*drand());
            mu[kt*nzmax_s + jt] = (double)1;
            theta[dt*Ktopic + kt] += xt;
        }
    }
    
    /*start iterating and calculating predictive perplexity while passing messages asynchronously*/
    for (iter = 0; iter < Titer; iter++)
    {
        /*calculating predictive perplexity*/
        if ((iter%10 == 0)&&(iter != 0))
        {
            perplexity[0] = 0.0;
            for (dt = 0; dt < D_s; dt++)
            {
                for (jt = (int)col_s[dt]; jt < col_s[dt + 1]; jt++)
                {
                    wt = (int)row_s[jt];
                    xt = ele_s[jt];
                    perp = 0.0;
                    for (kt = 0; kt < Ktopic; kt++)
                    {
                        perp += ((double)theta[dt*Ktopic + kt] + ALPHA)/((double)kw_mu[dt] + kalpha)
                                *((double)phi[wt*Ktopic + kt] + BETA)/((double)wd_mu[kt] + wbeta);
                    }
                    perplexity[0] -= (xt*log(perp));
                }
            }
            perplexity[0] = exp(perplexity[0]/x_total);
            mexPrintf("Perplexity of %d of Iteration %d is: %f\n", iter, Titer, perplexity[0]);
            mexEvalString("drawnow;"); 
        }
        
        /*passing messages asynchronously*/
        for (dt = 0; dt < D_s; dt++)
        {
            for (jt = (int)col_s[dt]; jt < col_s[dt + 1]; jt++)
            {
                wt = (int)row_s[jt];
                xt = ele_s[jt];
                mu_temp = 0.0;
                for (kt = 0; kt < Ktopic; kt++)
                {
                    /*subscrapting the old message*/
                    theta[dt*Ktopic + kt] = theta[dt*Ktopic + kt] - (double)xt*mu[kt*nzmax_s + jt];
                    /*updating the message on site dwk*/
                    mu[kt*nzmax_s + jt] = ((double)theta[dt*Ktopic + kt] + ALPHA)/((double)wd_mu[kt] + wbeta)
                                          *((double)phi[wt*Ktopic + kt] + BETA);
                    mu_temp += mu[kt*nzmax_s + jt];
                }
                for (kt = 0; kt < Ktopic; kt++)
                {
                    mu[kt*nzmax_s + jt] = mu[kt*nzmax_s + jt]/mu_temp;
                    theta[dt*Ktopic + kt] = theta[dt*Ktopic + kt] + (double)xt*mu[kt*nzmax_s + jt];
                }
            }
        }
    }
    /*free the memory allocated after the iteration*/
    mxFree(theta);
    mxFree(mu);
    mxFree(kw_mu);
    mxFree(wd_mu);
    
}

/*interface of C and matlab*/
void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    /*variable-definition*/
    int W, D_t, D_s, Ktopic, Titer, nzmax_t, nzmax_s, SEED;
    double ALPHA, BETA;
    double *phi, *ele_t, *ele_s, *perplexity;
    mwIndex *row_t, *col_t, *row_s, *col_s;
    
    
    /*getting variables*/
    /*the training data and the test data have been divided???*/
    if (mxIsDouble(prhs[0]) != 1) mexErrMsgTxt("The training data must be a double precision matrix!");
    ele_t = mxGetPr(prhs[0]);
    row_t = mxGetIr(prhs[0]);
    col_t = mxGetJc(prhs[0]);
    nzmax_t = (int)mxGetNzmax(prhs[0]);
    W = (int)mxGetM(prhs[0]);
    D_t = (int)mxGetN(prhs[0]);
    
    if (mxIsDouble(prhs[1]) != 1) mexErrMsgTxt("The test data must be a double precision matrix!");
    ele_s = mxGetPr(prhs[1]);
    row_s = mxGetIr(prhs[1]);
    col_s = mxGetJc(prhs[1]);
    nzmax_s = (int)mxGetNzmax(prhs[1]);
    D_s = (int)mxGetN(prhs[1]);
    
    if (prhs[2] <= 0) mexErrMsgTxt("Number of topic must be greater than zero!");
    Ktopic = (int)mxGetScalar(prhs[2]);
    
    if (prhs[3] < 0) mexErrMsgTxt("Number of iteration must be greater than zero!");
    Titer = (int)mxGetScalar(prhs[3]);
    
    if (prhs[4] < 0) mexErrMsgTxt("ALPHA must be greater than zero!");
    ALPHA = (double)mxGetScalar(prhs[4]);
    
    if (prhs[5] < 0) mexErrMsgTxt("BETA must be greater than zero!");
    BETA = (double)mxGetScalar(prhs[5]);
   
    SEED = (int)mxGetScalar(prhs[6]);
    
    /*allocating memory*/
    phi = (double*)mxCalloc(W*Ktopic, sizeof(double));
    perplexity = (double*)mxCalloc(1, sizeof(double));
    
    /*call the main functions to structure the processor*/
    seedMT(1 + 2*SEED);
    
    as_training(W, D_t, Ktopic, Titer, nzmax_t, ALPHA, BETA, row_t, col_t, ele_t, phi);
    as_predicting(W, D_s, Ktopic, Titer, nzmax_s, ALPHA, BETA, row_s, col_s, ele_s, phi, perplexity);
    
    plhs[0] = mxCreateDoubleMatrix(1,1,mxREAL);
    mxSetPr(plhs[0],perplexity);
}
