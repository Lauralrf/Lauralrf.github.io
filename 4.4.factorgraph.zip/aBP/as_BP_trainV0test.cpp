/*This code is to realize the asychronize message passing of BP algorithm focus on factor nodes on LDA
 It is just training on the whole dataset, and calculating the Training Preplexity about every 10 iterations.*/

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <math.h>
#include <string.h>
#include <mex.h>
#include "topiclib.cpp"

//the asychronize BP algorithm training function
void asBP_train(int W, int D, int Ktopic, int Titer, int nzmax, double ALPHA, double BETA, mwIndex *row, mwIndex *row_r, mwIndex *col,
                mwIndex *col_r, double *ele, double *ele_r, double *theta, double *phi, double *mu, double *mu_last)//, double *perp)
{
    /*variations' definition*/
    int dt, wt, jt, kt, iter, n = 0, i, j, count, index = 0;
    double xt, mu_temp, x_total = 0.0, perplexity = 0.0;
    double kalpha = (double)Ktopic*ALPHA;
    double wbeta = (double)W*BETA;
    double *kw_mu, *wd_mu;
    
    kw_mu = (double*)mxCalloc(D, sizeof(double));
    wd_mu = (double*)mxCalloc(Ktopic, sizeof(double));
    
    /*initialization of topic configuration for wd matrix*/
    for (dt = 0; dt < D; dt++){
        for (jt = (int)col[dt]; jt < col[dt + 1]; jt++){
            wt = (int)row[jt];
            xt = ele[jt];
            x_total += xt;
            kw_mu[dt] += xt;
            //configurating topic to wd matrix randomly
            kt = (int)(Ktopic * drand());
            mu[kt*nzmax + jt] = (double)1;
            mu_last[kt*nzmax + jt] = (double)1;
            theta[dt*Ktopic + kt] += xt;
            phi[wt*Ktopic + kt] += xt;
            wd_mu[kt] += xt;
        }
    }
    
    /*training iteration*/
    for (iter = 0; iter < Titer; iter++){
        /*calculating training perplexity*/
        if ((iter%10 == 0)&&(iter != 0)){
            perplexity = 0;
            for (dt = 0; dt < D; dt++){
                for (jt = (int)col[dt]; jt < col[dt + 1]; jt++){
                    wt = (int)row[jt];                     
                    xt = ele[jt];
                    mu_temp = 0;
                    for (kt = 0; kt < Ktopic; kt++){
                        mu_temp += (theta[dt*Ktopic + kt] + ALPHA)/(kw_mu[dt] + kalpha)
                                   *(phi[wt*Ktopic + kt] + BETA)/(wd_mu[kt] + wbeta);
                        if(mu_temp<=0){
                           mexPrintf("mu_temp:%f on site(%d,%d) when kt:%d smaller than 0\n",mu_temp,wt,dt,kt);
                           break;
                        }
                    }
                    if(mu_temp<=0){
                        break;
                    }
                    perplexity -= (xt*log(mu_temp));
                }
            }
            perplexity = exp(perplexity/x_total);
            mexPrintf("Iteration %d of %d is: %f\n", iter, Titer, perplexity);
            if ((iter % 10)==0) mexEvalString("drawnow;");
        }
        
       /*updating*/
        /**************updating phi*********************/
        for (dt = 0; dt < D; dt++){
            for (jt = (int)col[dt]; jt < col[dt + 1]; jt++){
                wt = (int)row[jt];
                xt = ele[jt];
                mu_temp = (double)0;
                //mexPrintf("at site(%d,%d)\tbefore:\n",wt,dt);
                for (kt = 0; kt < Ktopic; kt++){
                   // mexPrintf("kt:%d\tmu:%f\txt*mu:%f\tphi:%f\ttheta:%f\twd_mu:%f\n",kt,mu[kt*nzmax + jt],xt*mu[kt*nzmax + jt],phi[wt*Ktopic + kt],theta[dt*Ktopic + kt],wd_mu[kt]);
                    phi[wt*Ktopic + kt] = phi[wt*Ktopic + kt] - xt*mu[kt*nzmax + jt];
                    wd_mu[kt] = wd_mu[kt] - xt*mu[kt*nzmax + jt];
                    /*calculate the current message vertex as formulation*/
                    mu[kt*nzmax + jt] = (theta[dt*Ktopic + kt] - xt*mu_last[kt*nzmax + jt]+ ALPHA)/(wd_mu[kt] + wbeta)
                                        *(phi[wt*Ktopic + kt] +BETA);
                    mu_temp += mu[kt*nzmax +jt];
                }
                //mexPrintf("after:\tmutemp:%f\n",mu_temp);
                for (kt = 0; kt < Ktopic; kt++){
                    mu[kt*nzmax + jt] = mu[kt*nzmax + jt]/mu_temp;
                    /*update the factor functions using the new message*/
                    phi[wt*Ktopic + kt] = phi[wt*Ktopic + kt] + xt*mu[kt*nzmax + jt];
                    wd_mu[kt] = wd_mu[kt] + xt*mu[kt*nzmax + jt];
                    //mexPrintf("kt:%d\tmu:%f\txt*mu:%f\tphi:%f\ttheta:%f\twd_mu:%f\n",kt,mu[kt*nzmax + jt],xt*mu[kt*nzmax + jt],phi[wt*Ktopic + kt],theta[dt*Ktopic + kt],wd_mu[kt]);
                }
            }
        }
        /***********************updating theta***************************/
        for (wt = 0; wt < W; wt++){
            for (j = (int)row_r[wt]; j < row_r[wt + 1]; j++){
                dt = (int)col_r[j];
                for (jt = (int)col[dt]; jt < col[dt + 1]; jt++){
                    if ((int)row[jt] == wt) break;
                }
                xt = ele[jt];
                mu_temp = (double)0;
                //mexPrintf("at site(%d,%d)\tbefore:\n",wt,dt);
                for (kt = 0; kt < Ktopic; kt++){
                   // mexPrintf("kt:%d\tmu:%f\txt*mu:%f\tphi:%f\ttheta:%f\twd_mu:%f\n",kt,mu[kt*nzmax + jt],xt*mu[kt*nzmax + jt],phi[wt*Ktopic + kt],theta[dt*Ktopic + kt],wd_mu[kt]);
                    theta[dt*Ktopic + kt] = theta[dt*Ktopic + kt] - xt*mu_last[kt*nzmax + jt];
                    wd_mu[kt] = wd_mu[kt] - xt*mu_last[kt*nzmax + jt];
                    /*calculate the current message vertex as formulation*/
                    mu_last[kt*nzmax + jt] = (theta[dt*Ktopic + kt] + ALPHA)/(wd_mu[kt] + wbeta)
                                        *(phi[wt*Ktopic + kt] - xt*mu[kt*nzmax + jt] +BETA);
                    mu_temp += mu_last[kt*nzmax +jt];
                }
                //mexPrintf("after:\tmutemp:%f\n",mu_temp);
                for (kt = 0; kt < Ktopic; kt++){
                    mu_last[kt*nzmax + jt] = mu_last[kt*nzmax + jt]/mu_temp;
                    /*update the factor functions using the new message*/
                    theta[dt*Ktopic + kt] = theta[dt*Ktopic + kt] + xt*mu_last[kt*nzmax + jt];
                    wd_mu[kt] = wd_mu[kt] + xt*mu_last[kt*nzmax + jt];//????????????mu or mu_last???
                    //mexPrintf("kt:%d\tmu:%f\txt*mu:%f\tphi:%f\ttheta:%f\twd_mu:%f\n",kt,mu[kt*nzmax + jt],xt*mu[kt*nzmax + jt],phi[wt*Ktopic + kt],theta[dt*Ktopic + kt],wd_mu[kt]);
                }
            }
        }
    }
   mxFree(kw_mu);
   mxFree(wd_mu);
}

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]){
    /*variations' definition*/
    int W, D, nzmax, Ktopic, Titer, SEED;//, i;
    double ALPHA, BETA;
    double *theta, *phi, *mu, *mu_last, *ele, *ele_r;//, *perp;
    mwIndex *row, *col, *col_r, *row_r;
    
    /*getting variations*/
    if (mxIsDouble(prhs[0]) != 1) mexErrMsgTxt("The wd must be a double matrix!");
    ele = mxGetPr(prhs[0]);
    row = mxGetIr(prhs[0]);
    col = mxGetJc(prhs[0]);
    nzmax = (int)mxGetNzmax(prhs[0]);
    W = (int)mxGetM(prhs[0]);
    D = (int)mxGetN(prhs[0]);
    
    if (mxIsDouble(prhs[1]) != 1) mexErrMsgTxt("The WD must be double precision matrix!");
    ele_r = mxGetPr(prhs[1]);
    col_r = mxGetIr(prhs[1]);
    row_r = mxGetJc(prhs[1]);
    
    if (prhs[2] <= 0) mexErrMsgTxt("Number of topics must be greater than zero!");
    Ktopic = (int)mxGetScalar(prhs[2]);
    
    if (prhs[3] <= 0) mexErrMsgTxt("Number of iteration must be greater than zero!");
    Titer = (int)mxGetScalar(prhs[3]);
    
    if (prhs[4] <= 0) mexErrMsgTxt("ALPHA must be greater than zero!");
    ALPHA = (double)mxGetScalar(prhs[4]);
    
    if (prhs[5] <= 0) mexErrMsgTxt("BETA must be greater than zero!");
    BETA = (double)mxGetScalar(prhs[5]);
    
    SEED = (int)mxGetScalar(prhs[6]);
    
    //allocating the inner memory
    theta = (double*)mxCalloc(D*Ktopic, sizeof(double));
    phi = (double*)mxCalloc(W*Ktopic, sizeof(double));
    mu = (double*)mxCalloc(Ktopic*nzmax, sizeof(double));
    mu_last = (double*)mxCalloc(Ktopic*nzmax, sizeof(double));
    
        
    //call the training function
    seedMT(1 + 2*SEED);
    
    /*void asBP_train(int W, int D, int Ktopic, int T, int nzmax, double ALPHA, double BETA, mwIndex *row, mwIndex *col,
                double *ele, double *theta, double *phi, double *mu, double *perp)*/
    asBP_train(W, D, Ktopic, Titer, nzmax, ALPHA, BETA, row, row_r, col, col_r, ele, ele_r, theta, phi, mu, mu_last);  
    
    //plhs[0] = mxCreateDoubleMatrix(1,1,mxREAL);
    //mxSetPr(plhs[0], perp);
}
