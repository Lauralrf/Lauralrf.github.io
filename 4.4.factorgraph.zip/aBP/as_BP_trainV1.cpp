/*This code is to realize the asychronize message passing of BP algorithm on LDA
 It is just training on the whole dataset, and calculating the Training Preplexity about every 10 iterations.*/

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <math.h>
#include <string.h>
#include <mex.h>
#include "topiclib.cpp"

//the asychronize BP algorithm training function
void asBP_train(int W, int D, int Ktopic, int Titer, int nzmax, double ALPHA, double BETA, mwIndex *row, mwIndex *col,
                double *ele, double *theta, double *phi, double *mu)//, double *perp)
{
    /*variations' definition*/
    int dt, wt, jt, kt, iter, n = 0;
    double xt, mu_temp, x_total = 0.0, perplexity = 0.0;
    double kalpha = (double)Ktopic*ALPHA;
    double wbeta = (double)W*BETA;
    double *kw_mu, *wd_mu;
    
    kw_mu = (double*)mxCalloc(D, sizeof(double));
    wd_mu = (double*)mxCalloc(Ktopic, sizeof(double));
    
    /*initialization of topic configuration for wd matrix*/
    for (dt = 0; dt < D; dt++){
        for (jt = (int)col[dt]; jt < col[dt + 1]; jt++){
            wt = (int)row[jt];
            xt = ele[jt];
            x_total += xt;
            kw_mu[dt] += xt;
            //configurating topic to wd matrix randomly
            kt = (int)(Ktopic * drand());
            mu[kt*nzmax + jt] = (double)1;
            theta[dt*Ktopic + kt] += xt;
            phi[wt*Ktopic + kt] += xt;
            wd_mu[kt] += xt;
        }
    }
    
    /*training iteration*/
    for (iter = 0; iter < Titer; iter++){
        /*calculating training perplexity*/
        if ((iter%10 == 0)&&(iter != 0)){
            perplexity = 0;
            for (dt = 0; dt < D; dt++){
                for (jt = (int)col[dt]; jt < col[dt + 1]; jt++){
                    wt = (int)row[jt];
                    xt = ele[jt];
                    mu_temp = 0;
                    for (kt = 0; kt < Ktopic; kt++){
                        mu_temp += (theta[dt*Ktopic + kt] + ALPHA)/(kw_mu[dt] + kalpha)
                                   *(phi[wt*Ktopic + kt] + BETA)/(wd_mu[kt] + wbeta);
                    }
                    perplexity -= (xt*log(mu_temp));
                }
            }
            perplexity = exp(perplexity/x_total);
            mexPrintf("Iteration %d of %d is: %f\n", iter, Titer, perplexity);
            if ((iter % 10)==0) mexEvalString("drawnow;");
        }
        
        /*asychronize message passing,update every document vertex by normal order*/
        for (dt = 0; dt < D; dt++){
            for (jt = (int)col[dt]; jt < col[dt + 1]; jt++){
                wt = (int)row[jt];
                xt = ele[jt];
                mu_temp = (double)0;
                for (kt = 0; kt < Ktopic; kt++){
                    /*clear the old message*/
                    theta[dt*Ktopic + kt] = theta[dt*Ktopic + kt] - xt*mu[kt*nzmax + jt];
                    phi[wt*Ktopic + kt] = phi[wt*Ktopic + kt] - xt*mu[kt*nzmax + jt];
                    wd_mu[kt] = wd_mu[kt] - xt*mu[kt*nzmax + jt];
                    /*calculate the current message vertex as formulation*/
                    mu[kt*nzmax + jt] = (theta[dt*Ktopic + kt] + xt*mu[kt*nzmax + jt]+ ALPHA)/(wd_mu[kt] + xt*mu[kt*nzmax + jt]+ wbeta)
                                        *(phi[wt*Ktopic + kt] + xt*mu[kt*nzmax + jt]+BETA);
                    mu_temp += mu[kt*nzmax +jt];
                }
                for (kt = 0; kt < Ktopic; kt++){
                    mu[kt*nzmax + jt] = mu[kt*nzmax + jt]/mu_temp;
                    /*update the factor functions using the new message*/
                    theta[dt*Ktopic + kt] = theta[dt*Ktopic + kt] + xt*mu[kt*nzmax + jt];
                    phi[wt*Ktopic + kt] = phi[wt*Ktopic + kt] + xt*mu[kt*nzmax + jt];
                    wd_mu[kt] = wd_mu[kt] + xt*mu[kt*nzmax + jt];
                }
            }
        }
    }
   mxFree(kw_mu);
   mxFree(wd_mu);
}

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]){
    /*variations' definition*/
    int W, D, nzmax, Ktopic, Titer, SEED;//, i;
    double ALPHA, BETA;
    double *theta, *phi, *mu, *ele;//, *perp;
    mwIndex *row, *col;
    
    /*getting variations*/
    if (mxIsDouble(prhs[0]) != 1) mexErrMsgTxt("The wd must be a double matrix!");
    ele = mxGetPr(prhs[0]);
    row = mxGetIr(prhs[0]);
    col = mxGetJc(prhs[0]);
    nzmax = (int)mxGetNzmax(prhs[0]);
    W = (int)mxGetM(prhs[0]);
    D = (int)mxGetN(prhs[0]);
    
    if (prhs[1] <= 0) mexErrMsgTxt("Number of topics must be greater than zero!");
    Ktopic = (int)mxGetScalar(prhs[1]);
    
    if (prhs[2] <= 0) mexErrMsgTxt("Number of iteration must be greater than zero!");
    Titer = (int)mxGetScalar(prhs[2]);
    
    if (prhs[3] <= 0) mexErrMsgTxt("ALPHA must be greater than zero!");
    ALPHA = (double)mxGetScalar(prhs[3]);
    
    if (prhs[4] <= 0) mexErrMsgTxt("BETA must be greater than zero!");
    BETA = (double)mxGetScalar(prhs[4]);
    
    SEED = (int)mxGetScalar(prhs[5]);
    
    //allocating the inner memory
    theta = (double*)mxCalloc(D*Ktopic, sizeof(double));
    phi = (double*)mxCalloc(W*Ktopic, sizeof(double));
    mu = (double*)mxCalloc(Ktopic*nzmax, sizeof(double));
    
        
    //call the training function
    seedMT(1 + 2*SEED);
    
    /*void asBP_train(int W, int D, int Ktopic, int T, int nzmax, double ALPHA, double BETA, mwIndex *row, mwIndex *col,
                double *ele, double *theta, double *phi, double *mu, double *perp)*/
    asBP_train(W, D, Ktopic, Titer, nzmax, ALPHA, BETA, row, col, ele, theta, phi, mu);  
    
    //plhs[0] = mxCreateDoubleMatrix(1,1,mxREAL);
    //mxSetPr(plhs[0], perp);
}
