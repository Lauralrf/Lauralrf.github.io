/*This project is to predict the unseen documents' topic configuration
 and calculate the predictive perplexity.
 the processing can be divided into two parts:
 1.training theta and phi on the training dataset
 2.adoting the phi's dimension on test data, 
   and calculating the predictive perplexity at the same time.
 the passing method of messages is asynchronous.*/

/*link files*/
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string> 
#include <math.h>
#include <mex.h>
#include "topiclib.cpp"

/*training on the training dataset*/
void as_training(int W, int D_t, int Ktopic, int Titer, int nzmax_t, double ALPHA, double BETA,
                 mwIndex *row_t, mwIndex *row_tr, mwIndex *col_t, mwIndex *col_tr, double *ele_t, double *ele_tr, double *phi)
{
   /*variable-definition*/
   int dt, wt, kt, jt, iter, j;
   double xt, x_total = 0.0, mu_temp = 0.0, perplexity;
   double kalpha = (double)Ktopic*ALPHA;
   double wbeta = (double)W*BETA;
   double *theta, *mu, *mu_last, *kw_mu, *wd_mu;
   
   /*allocating memory*/
   theta = (double*)mxCalloc(D_t*Ktopic, sizeof(double));   
   mu = (double*)mxCalloc(Ktopic*nzmax_t, sizeof(double));
   mu_last = (double*)mxCalloc(Ktopic*nzmax_t, sizeof(double));
   kw_mu = (double*)mxCalloc(D_t, sizeof(double));
   wd_mu = (double*)mxCalloc(Ktopic, sizeof(double));
   
   /*initialization*/
   for (dt = 0; dt < D_t; dt++)
   {
       for (jt = (int)col_t[dt]; jt < col_t[dt + 1]; jt++)
       {
           xt = ele_t[jt];
           wt = (int)row_t[jt];
           x_total += xt;
           kw_mu[dt] += xt;
           /*pick up topic of wd randomly*/
           kt = (int)(Ktopic*drand());
           mu[kt*nzmax_t + jt] = (double)1;
		   mu_last[kt*nzmax_t + jt] = (double)1;
           theta[dt*Ktopic + kt] += xt;
           phi[wt*Ktopic + kt] += xt;
           wd_mu[kt] += xt;
       }
   }
   
   /*start iterating and message updating*/
   for (iter = 0; iter < Titer; iter++)
   {
	   /**********************calculating perplexity***********/
	   if ((iter%10 == 0)&&(iter != 0)){
            perplexity = 0;
            for (dt = 0; dt < D_t; dt++){
                for (jt = (int)col_t[dt]; jt < col_t[dt + 1]; jt++){
                    wt = (int)row_t[jt];                     
                    xt = ele_t[jt];
                    mu_temp = 0;
                    for (kt = 0; kt < Ktopic; kt++){
                        mu_temp += (theta[dt*Ktopic + kt] + ALPHA)/(kw_mu[dt] + kalpha)
                                   *(phi[wt*Ktopic + kt] + BETA)/(wd_mu[kt] + wbeta);
                        if(mu_temp<=0){
                           mexPrintf("mu_temp:%f on site(%d,%d) when kt:%d smaller than 0\n",mu_temp,wt,dt,kt);
                           break;
                        }
                    }
                    if(mu_temp<=0){
                        break;
                    }
                    perplexity -= (xt*log(mu_temp));
                }
            }
            perplexity = exp(perplexity/x_total);
            mexPrintf("Iteration %d of %d is: %f\n", iter, Titer, perplexity);
            if ((iter % 10)==0) mexEvalString("drawnow;");
        }
        /**************updating phi*********************/
        for (dt = 0; dt < D_t; dt++){
            for (jt = (int)col_t[dt]; jt < col_t[dt + 1]; jt++){
                wt = (int)row_t[jt];
                xt = ele_t[jt];
                mu_temp = (double)0;
                //mexPrintf("at site(%d,%d)\tbefore:\n",wt,dt);
                for (kt = 0; kt < Ktopic; kt++){
                   // mexPrintf("kt:%d\tmu:%f\txt*mu:%f\tphi:%f\ttheta:%f\twd_mu:%f\n",kt,mu[kt*nzmax + jt],xt*mu[kt*nzmax + jt],phi[wt*Ktopic + kt],theta[dt*Ktopic + kt],wd_mu[kt]);
                    phi[wt*Ktopic + kt] = phi[wt*Ktopic + kt] - xt*mu[kt*nzmax_t + jt];
                    wd_mu[kt] = wd_mu[kt] - xt*mu[kt*nzmax_t + jt];
                    /*calculate the current message vertex as formulation*/
                    mu[kt*nzmax_t + jt] = (theta[dt*Ktopic + kt] - xt*mu_last[kt*nzmax_t + jt]+ ALPHA)/(wd_mu[kt] + wbeta)
                                        *(phi[wt*Ktopic + kt] +BETA);
                    mu_temp += mu[kt*nzmax_t +jt];
                }
                //mexPrintf("after:\tmutemp:%f\n",mu_temp);
                for (kt = 0; kt < Ktopic; kt++){
                    mu[kt*nzmax_t + jt] = mu[kt*nzmax_t + jt]/mu_temp;
                    phi[wt*Ktopic + kt] = phi[wt*Ktopic + kt] + xt*mu[kt*nzmax_t + jt];
                    wd_mu[kt] = wd_mu[kt] + xt*mu[kt*nzmax_t + jt];
                    //mexPrintf("kt:%d\tmu:%f\txt*mu:%f\tphi:%f\ttheta:%f\twd_mu:%f\n",kt,mu[kt*nzmax + jt],xt*mu[kt*nzmax + jt],phi[wt*Ktopic + kt],theta[dt*Ktopic + kt],wd_mu[kt]);
                }
            }
        }
        /***********************updating theta***************************/
        for (wt = 0; wt < W; wt++){
            for (j = (int)row_tr[wt]; j < row_tr[wt + 1]; j++){
                dt = (int)col_tr[j];
                for (jt = (int)col_t[dt]; jt < col_t[dt + 1]; jt++){
                    if ((int)row_t[jt] == wt) break;
                }
                xt = ele_t[jt];
                mu_temp = (double)0;
                //mexPrintf("at site(%d,%d)\tbefore:\n",wt,dt);
                for (kt = 0; kt < Ktopic; kt++){
                   // mexPrintf("kt:%d\tmu:%f\txt*mu:%f\tphi:%f\ttheta:%f\twd_mu:%f\n",kt,mu[kt*nzmax + jt],xt*mu[kt*nzmax + jt],phi[wt*Ktopic + kt],theta[dt*Ktopic + kt],wd_mu[kt]);
                    theta[dt*Ktopic + kt] = theta[dt*Ktopic + kt] - xt*mu_last[kt*nzmax_t + jt];
                    wd_mu[kt] = wd_mu[kt] - xt*mu_last[kt*nzmax_t + jt];
                    /*calculate the current message vertex as formulation*/
                    mu_last[kt*nzmax_t + jt] = (theta[dt*Ktopic + kt] + ALPHA)/(wd_mu[kt] + wbeta)
                                        *(phi[wt*Ktopic + kt] - xt*mu[kt*nzmax_t + jt] +BETA);
                    mu_temp += mu_last[kt*nzmax_t +jt];
                }
                //mexPrintf("after:\tmutemp:%f\n",mu_temp);
                for (kt = 0; kt < Ktopic; kt++){
                    mu_last[kt*nzmax_t + jt] = mu_last[kt*nzmax_t + jt]/mu_temp;
                    theta[dt*Ktopic + kt] = theta[dt*Ktopic + kt] + xt*mu_last[kt*nzmax_t + jt];
                    wd_mu[kt] = wd_mu[kt] + xt*mu_last[kt*nzmax_t + jt];
                    //mexPrintf("kt:%d\tmu:%f\txt*mu:%f\tphi:%f\ttheta:%f\twd_mu:%f\n",kt,mu[kt*nzmax + jt],xt*mu[kt*nzmax + jt],phi[wt*Ktopic + kt],theta[dt*Ktopic + kt],wd_mu[kt]);
                }
            }
        }
   }
   /*after iterating,free the memory that allocated before*/
   mxFree(theta);
   mxFree(mu);
   mxFree(mu_last);
   mxFree(kw_mu);
   mxFree(wd_mu);
}

/*adoting and calculating the predictive perplexity*/
//void as_predicting(int W, int D_s, int Ktopic, int Titer, int nzmax_s, double ALPHA, double BETA, mwIndex *row_s, mwIndex *row_sr,
                   //mwIndex *col_s, mwIndex *col_sr, double *ele_s, double *ele_sr, double *phi, double *perplexity)
void as_predicting(int W, int D_s, int Ktopic, int Titer, int nzmax_s, double ALPHA, double BETA, mwIndex *row_s,
                   mwIndex *col_s, double *ele_s, double *phi, double *perplexity)
{
    /*variable-definition*/
    int dt, wt, kt, jt, iter;
    double xt, x_total = 0.0, mu_temp = 0, perp = 0.0;
    double kalpha = (double)Ktopic*ALPHA;
    double wbeta = (double)W*BETA;
    double *theta, *mu, *kw_mu, *wd_mu;
    
    /*allocating memory*/
    theta = (double*)mxCalloc(D_s*Ktopic, sizeof(double));   
    mu = (double*)mxCalloc(Ktopic*nzmax_s, sizeof(double));
	//mu_last = (double*)mxCalloc(Ktopic*nzmax_s, sizeof(double));
    kw_mu = (double*)mxCalloc(D_s, sizeof(double));
    wd_mu = (double*)mxCalloc(Ktopic, sizeof(double));
    
    /*initialization when phi is fixed*/
    for (wt = 0; wt < W; wt++)
    {
        for (kt = 0; kt < Ktopic; kt++)
        {
            wd_mu[kt] += phi[wt*Ktopic + kt];
        }
    }
    
    for (dt = 0; dt < D_s; dt++)
    {
        for (jt = (int)col_s[dt]; jt < col_s[dt + 1]; jt++)
        {
            wt = (int)row_s[jt];
            xt = ele_s[jt];
            x_total += xt;
            kw_mu[dt] += xt;
            /*pick up topic randomly*/
            kt = (int)(Ktopic*drand());
            mu[kt*nzmax_s + jt] = (double)1;
			//mu_last[kt*nzmax_s + jt] = (double)1;
            theta[dt*Ktopic + kt] += xt;
        }
    }
    
    /*start iterating and calculating predictive perplexity while passing messages asynchronously*/
    for (iter = 0; iter < Titer; iter++)
    {
        /*calculating predictive perplexity*/
        if ((iter%10 == 0)&&(iter != 0))
        {
            perplexity[0] = 0.0;
            for (dt = 0; dt < D_s; dt++)
            {
                for (jt = (int)col_s[dt]; jt < col_s[dt + 1]; jt++)
                {
                    wt = (int)row_s[jt];
                    xt = ele_s[jt];
                    perp = 0.0;
                    for (kt = 0; kt < Ktopic; kt++)
                    {
                        perp += ((double)theta[dt*Ktopic + kt] + ALPHA)/((double)kw_mu[dt] + kalpha)
                                *((double)phi[wt*Ktopic + kt] + BETA)/((double)wd_mu[kt] + wbeta);
                    }
                    perplexity[0] -= (xt*log(perp));
                }
            }
            perplexity[0] = exp(perplexity[0]/x_total);
            mexPrintf("Perplexity of %d of Iteration %d is: %f\n", iter, Titer, perplexity[0]);
            mexEvalString("drawnow;"); 
        }
        
        /*passing messages asynchronously*/
        for (dt = 0; dt < D_s; dt++)//is this OK if I update it out of order????
        {
            for (jt = (int)col_s[dt]; jt < col_s[dt + 1]; jt++)
            {
                wt = (int)row_s[jt];
                xt = ele_s[jt];
                mu_temp = 0.0;
                for (kt = 0; kt < Ktopic; kt++)
                {
                    /*subscrapting the old message*/
                    theta[dt*Ktopic + kt] = theta[dt*Ktopic + kt] - (double)xt*mu[kt*nzmax_s + jt];
                    /*updating the message on site dwk*//*phi and wd_mu don't substract?*/
                    mu[kt*nzmax_s + jt] = ((double)theta[dt*Ktopic + kt] + ALPHA)/((double)wd_mu[kt] + wbeta)
                                          *((double)phi[wt*Ktopic + kt] + BETA);
                    mu_temp += mu[kt*nzmax_s + jt];
                }
                for (kt = 0; kt < Ktopic; kt++)
                {
                    mu[kt*nzmax_s + jt] = mu[kt*nzmax_s + jt]/mu_temp;
                    theta[dt*Ktopic + kt] = theta[dt*Ktopic + kt] + (double)xt*mu[kt*nzmax_s + jt];
                }
            }
        }
    }
    /*free the memory allocated after the iteration*/
    mxFree(theta);
    mxFree(mu);
    mxFree(kw_mu);
    mxFree(wd_mu);
    
}

/*interface of C and matlab*/
void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    /*variable-definition*/
    int W, D_t, D_s, Ktopic, Titer, nzmax_t, nzmax_s, SEED;
    double ALPHA, BETA;
    double *phi, *ele_t, *ele_s, *ele_tr, *perplexity;
    mwIndex *row_t, *col_t, *row_s, *col_s, *row_tr, *col_tr;
    
    
    /*getting variables*/
    /*getting training data*/
    if (mxIsDouble(prhs[0]) != 1) mexErrMsgTxt("The training matrix must be a double precision matrix!");
    ele_t = mxGetPr(prhs[0]);
    row_t = mxGetIr(prhs[0]);
    col_t = mxGetJc(prhs[0]);
    nzmax_t = (int)mxGetNzmax(prhs[0]);
    W = (int)mxGetM(prhs[0]);
    D_t = (int)mxGetN(prhs[0]);
	
	if (mxIsDouble(prhs[1]) != 1) mexErrMsgTxt("The transposited training matrix must be double precision!");
	ele_tr = mxGetPr(prhs[1]);
	col_tr = mxGetIr(prhs[1]);
	row_tr = mxGetJc(prhs[1]);
     
	/*getting predictive data*/
    if (mxIsDouble(prhs[2]) != 1) mexErrMsgTxt("The test matrix must be double precision!");
    ele_s = mxGetPr(prhs[2]);
    row_s = mxGetIr(prhs[2]);
    col_s = mxGetJc(prhs[2]);
    nzmax_s = (int)mxGetNzmax(prhs[2]);
    D_s = (int)mxGetN(prhs[2]);
	
	/*if (mxIsDouble(prhs[3]) != 1) mexErrMsgTxt("The predictive matrix must be double precision!");
	ele_sr = mxGetPr(prhs[3]);
	col_sr = mxGetIr(prhs[3]);
	row_sr = mxGetJc(prhs[3]);
	*/
    /*getting other data*/
    if (prhs[3] <= 0) mexErrMsgTxt("Number of topic must be greater than zero!");
    Ktopic = (int)mxGetScalar(prhs[3]);
    
    if (prhs[4] < 0) mexErrMsgTxt("Number of iteration must be greater than zero!");
    Titer = (int)mxGetScalar(prhs[4]);
    
    if (prhs[5] < 0) mexErrMsgTxt("ALPHA must be greater than zero!");
    ALPHA = (double)mxGetScalar(prhs[5]);
    
    if (prhs[6] < 0) mexErrMsgTxt("BETA must be greater than zero!");
    BETA = (double)mxGetScalar(prhs[6]);
   
    SEED = (int)mxGetScalar(prhs[7]);
    
    /*allocating memory*/
    phi = (double*)mxCalloc(W*Ktopic, sizeof(double));
    perplexity = (double*)mxCalloc(1, sizeof(double));
    
    /*call the main functions to structure the processor*/
    seedMT(1 + 2*SEED);
    
    as_training(W, D_t, Ktopic, Titer, nzmax_t, ALPHA, BETA, row_t, row_tr, col_t, col_tr, ele_t, ele_tr, phi);
	as_predicting(W, D_s, Ktopic, Titer, nzmax_s, ALPHA, BETA, row_s, col_s, ele_s, phi, perplexity);
   // as_predicting(W, D_s, Ktopic, Titer, nzmax_s, ALPHA, BETA, row_s, row_sr, col_s, col_sr, ele_s, ele_sr, phi, perplexity);
    
    plhs[0] = mxCreateDoubleMatrix(1,1,mxREAL);
    mxSetPr(plhs[0],perplexity);
}
