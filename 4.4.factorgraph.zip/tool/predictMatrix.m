%split matrix into two parts
%one is 90% part for training, the rest for predict

A = full(cora_wdA);
[W,D] = size(A);
TD = round(0.9*D);
trainM = zeros(W,TD);
predM = zeros(W,D-TD);

order = randperm(D);
for i=1:TD
    trainM(:,i) = A(:,order(1,i));
end
for i=(TD+1):D
    predM(:,i-TD) = A(:,order(1,i));
end

trainM = sparse(trainM);
predM = sparse(predM);

save('trainM.mat','trainM');
save('predM.mat','predM');
