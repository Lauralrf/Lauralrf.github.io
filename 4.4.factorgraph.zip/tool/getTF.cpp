/*calculating TF of word in a document*/

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string>
#include <fstream>
#include <math.h>
#include <mex.h>

using namespace std;

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    /*variations' definition*/
    int W = 0, D = 0, nzmax, dt, jt, wt;
    double xt, dx = 0,w_total = 0,times = 0, x_total = 0;
    double *ele,*tf;
    mwIndex *row, *col;
    
    /*get variations*/
    if(mxIsDouble(prhs[0]) != 1) mexErrMsgTxt("The WD must be a double matrix!");
    ele = mxGetPr(prhs[0]);
    row = mxGetIr(prhs[0]);
    col = mxGetJc(prhs[0]);
    nzmax = (int)mxGetNzmax(prhs[0]);
    W = (int)mxGetM(prhs[0]);
    D = (int)mxGetN(prhs[0]);
    
    
   /* for(dt = 0; dt < nzmax; dt++)
    {
        mexPrintf("%f\t",ele[dt]);
    }
    mexPrintf("\n");*/
    /*allocate inner memory*/
    tf = (double*)mxCalloc(nzmax, sizeof(double));
    
    /*calculate TF*/
    for (dt = 0; dt < D; dt++)
    {
        dx = 0;
        for (jt = (int)col[dt]; jt < col[dt + 1]; jt++)
        {
            dx += ele[jt];
        }
        x_total += dx;
       // mexPrintf("dt:%d\tdx:%f\t", dt, dx);
        for(jt = (int)col[dt]; jt < col[dt + 1]; jt++)
        {
            xt = ele[jt];
            tf[jt] = xt/dx;
            w_total += tf[jt];
        }
    }
    times = (double)x_total/w_total;
    for (dt = 0; dt < D;dt++){
        for (jt = (int)col[dt]; jt < col[dt+1]; jt++){
            wt = (int)row[jt];
            tf[jt] = tf[jt]*times;
        }
    }
    
    ofstream File;
    char *FileName = "tf_note.txt";
    File.open(FileName, ios::out);
    if (File){
        for(dt = 0; dt < nzmax; dt++)
        {
            File<<tf[dt]<<endl;
        }
    }else{
        mexErrMsgTxt("file global_note open failed!");
    }
    File.close();;
    //mexPrintf("\n");
    /*return the result*/
    plhs[0] = mxCreateDoubleMatrix(1, nzmax, mxREAL);
    mxSetPr(plhs[0], tf);
}