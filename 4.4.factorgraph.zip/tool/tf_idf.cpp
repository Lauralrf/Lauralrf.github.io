/*This file is to calculate the tf-idf on each dataset,
 and will using in training and predict taking charge of the Xwd to avoid bias.*/
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string>
#include <mex.h>
#include <fstream>
#include <math.h>

using namespace std;

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    /*variations' definition*/
    int W, D, nzmax, dt, wt, jt;
    double xt, x_total = 0, Nwd = 0, Ndw = 0, t_total = 0, times;
    double *ele, *tf, *idf, *ni, *nj, *tf_idf;
    mwIndex *row, *col;
    
    /*get variations from inputs*/
    if (mxIsDouble(prhs[0]) != 1) mexErrMsgTxt("The wd matrix must be double matrix!");
    
    ele = mxGetPr(prhs[0]);
    row = mxGetIr(prhs[0]);
    col = mxGetJc(prhs[0]);
    nzmax = (int)mxGetNzmax(prhs[0]);
    W = (int)mxGetM(prhs[0]);
    D = (int)mxGetN(prhs[0]);
    
    /*memory allocation*/
    nj = (double*)mxCalloc(D, sizeof(double));
    tf = (double*)mxCalloc(nzmax, sizeof(double));
    ni = (double*)mxCalloc(W, sizeof(double));
    idf = (double*)mxCalloc(W, sizeof(double));
    tf_idf = (double*)mxCalloc(nzmax, sizeof(double));
    
    /*calculating the tf and idf and tf-idf*/
    for (dt = 0; dt < D; dt++){
        for (jt = (int)col[dt]; jt < col[dt+1]; jt++){
            wt = (int)row[jt];
            xt = ele[jt];
            x_total += xt;
            nj[dt] += xt;
            ni[wt] += 1;
        }
        Ndw += nj[dt];
    }
    /*mexPrintf("nj:\n");
    for (dt = 0; dt < D; dt++){
        mexPrintf("%f\t",nj[dt]);
    }
    mexPrintf("\n");
    mexPrintf("ni:\n");
    for (wt = 0; wt < W; wt++){
        mexPrintf("%f\t",ni[wt]);
    }
    mexPrintf("\n");*/
    Nwd = nzmax;//number of positive elements is equal to the document count which include words w
    //averaging
    Ndw = (double)(Ndw / D);
    Nwd = (double)(D/(1+Nwd/W));
    for (dt = 0; dt < D; dt++){
        for (jt = (int)col[dt]; jt < col[dt+1]; jt++){
            wt = (int)row[jt];
            xt = ele[jt];
            tf[jt] = (double)xt/nj[dt];
            if (ni[wt]!=0){
                idf[wt] = (double)D/ni[wt];
            }else{//if ni[wt]=0
                idf[wt] = (double)D;
            }
            tf_idf[jt] = tf[jt]*log(idf[wt]);//*Ndw/log(Nwd);
            t_total += tf_idf[jt];
        }
    }
    
    times = x_total/t_total;
    for (jt = 0; jt < nzmax; jt++){
        wt = (int)row[jt];
        //Ϊ��ʹTF-IDF��X��ͬһ��������ֹperplexity����
        tf_idf[jt] = tf_idf[jt]*times;
        if ((tf_idf[jt] <= 0)||(tf_idf[jt] > 20))
            {
                mexPrintf("site(%d, %d) has x:%d idf:%f and tf_idf:%f\n", wt, jt, (int)ele[jt], idf[wt], tf_idf[jt]);
            }
    }
    
    /*mexPrintf("nj:\n");
    for (dt = 0; dt < D; dt++){
        mexPrintf("%f\t",nj[dt]);
    }
    mexPrintf("\n");
    mexPrintf("ni:\n");
    for (wt = 0; wt < W; wt++){
        mexPrintf("%f\t",ni[wt]);
    }
    mexPrintf("\n");*/
    
    /*save the result*/
    char *FileName = "tfidf_note.txt";
    ofstream File;
    File.open(FileName, ios::out);
    if (File){
        for (jt = 0 ;jt < nzmax; jt++){
            File<<tf_idf[jt]<<endl;
        }
    }else{
        mexErrMsgTxt("File tfidf_note open failed!");
    }
    File.close();
    
    
    plhs[0] = mxCreateDoubleMatrix(1, nzmax, mxREAL);
    mxSetPr(plhs[0], tf);
    
    plhs[1] = mxCreateDoubleMatrix(1, W, mxREAL);
    mxSetPr(plhs[1], idf);
    
    plhs[2] = mxCreateDoubleMatrix(1, D, mxREAL);
    mxSetPr(plhs[2], nj);
    
    plhs[3] = mxCreateDoubleMatrix(1, W, mxREAL);
    mxSetPr(plhs[3], ni);
    
    /*allocated memory free*/
}