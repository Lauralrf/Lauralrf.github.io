/*This file is to calculate the tf-icf on each dataset,
 and will using in training and predict taking charge of the Xwd to avoid bias.*/
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string>
#include <mex.h>
#include <fstream>
#include <math.h>

using namespace std;

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    /*variations' definition*/
    int W, D, nzmax, dt, wt, jt;
    double xt, x_total = 0, t_total, times;
    double *ele, *tf, *icf, *nd, *nw, *tf_icf;
    mwIndex *row, *col;
    
    /*get variations from inputs*/
    if (mxIsDouble(prhs[0]) != 1) mexErrMsgTxt("The wd matrix must be double matrix!");
    
    ele = mxGetPr(prhs[0]);
    row = mxGetIr(prhs[0]);
    col = mxGetJc(prhs[0]);
    nzmax = (int)mxGetNzmax(prhs[0]);
    W = (int)mxGetM(prhs[0]);
    D = (int)mxGetN(prhs[0]);
    
    /*memory allocation*/
    nd = (double*)mxCalloc(D, sizeof(double));
    tf = (double*)mxCalloc(nzmax, sizeof(double));
    nw = (double*)mxCalloc(W, sizeof(double));
    icf = (double*)mxCalloc(W, sizeof(double));
    tf_icf = (double*)mxCalloc(nzmax, sizeof(double));
    
    /*calculating the tf and idf and tf-idf*/
    for (dt = 0; dt < D; dt++){
        for (jt = (int)col[dt]; jt < col[dt+1]; jt++){
            wt = (int)row[jt];
            xt = ele[jt];
            x_total += xt;
            nd[dt] += xt;
            nw[wt] += xt;//���wt�Ĵʳ��ֵ��ܴ���
        }
    }
    /*mexPrintf("nj:\n");
    for (dt = 0; dt < D; dt++){
        mexPrintf("%f\t",nd[dt]);
    }
    mexPrintf("\n");
    mexPrintf("ni:\n");
    for (wt = 0; wt < W; wt++){
        mexPrintf("%f\t",nw[wt]);
    }
    mexPrintf("\n");*/
   
    //averaging
   
    for (dt = 0; dt < D; dt++){
        for (jt = (int)col[dt]; jt < col[dt+1]; jt++){
            wt = (int)row[jt];
            xt = ele[jt];
            tf[jt] = (double)xt/nd[dt];
            if (nw[wt]!=0){
                icf[wt] = x_total/nw[wt];
            }else{
                icf[wt] = x_total/(1 + nw[wt]);
            }
            tf_icf[jt] = tf[jt]*log(icf[wt]);
            t_total += tf_icf[jt];
        }
    }
    
    times = x_total/t_total;
    for (jt = 0; jt < nzmax; jt++){
        wt = (int)row[jt];
        tf_icf[jt] = tf_icf[jt]*times;
        if ((tf_icf[jt] <= 0)||(tf_icf[jt] > 20))
            {
                mexPrintf("site(%d, %d) has x:%d idf:%f and tf_icf:%f\n", wt, jt, (int)ele[jt], icf[wt], tf_icf[jt]);
            }
    }
    
    /*mexPrintf("nj:\n");
    for (dt = 0; dt < D; dt++){
        mexPrintf("%f\t",nj[dt]);
    }
    mexPrintf("\n");
    mexPrintf("ni:\n");
    for (wt = 0; wt < W; wt++){
        mexPrintf("%f\t",ni[wt]);
    }
    mexPrintf("\n");*/
    
    /*save the result*/
    char *FileName = "tficf_note.txt";
    ofstream File;
    File.open(FileName, ios::out);
    if (File){
        for (jt = 0 ;jt < nzmax; jt++){
            File<<tf_icf[jt]<<endl;
        }
    }else{
        mexErrMsgTxt("File tficf_note open failed!");
    }
    File.close();
    
    //���
    plhs[0] = mxCreateDoubleMatrix(1, nzmax, mxREAL);
    mxSetPr(plhs[0], tf);
    
    plhs[1] = mxCreateDoubleMatrix(1, W, mxREAL);
    mxSetPr(plhs[1], icf);
    
    plhs[2] = mxCreateDoubleMatrix(1, D, mxREAL);
    mxSetPr(plhs[2], nd);
    
    plhs[3] = mxCreateDoubleMatrix(1, W, mxREAL);
    mxSetPr(plhs[3], nw);
    
    /*allocated memory free*/
}