#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Image denoising module."""

beta=1e-3
eta=2.1e-3
h=0.0

import numpy as np
from PIL import Image

def E(x, y):
    """Calculate energy for matrices x, y.
    Formula:
    E = h * \sum{x_i} - beta * \sum{x_i x_j} - eta * \sum{x_i y_i}

    Note: the computation is not localized, so this is quite expensive.
    """
    # sum of products of neighboring paris {xi, yi}
    xxm = np.zeros_like(x)
    xxm[:-1, :] = x[1:, :]  # down
    xxm[1:, :] += x[:-1, :]  # up
    xxm[:, :-1] += x[:, 1:]  # right
    xxm[:, 1:] += x[:, :-1]  # left
    xx = np.sum(xxm * x)
    xy = np.sum(x * y)
    xsum = np.sum(x)
    return h * xsum - beta * xx - eta * xy


def localized_E(E1, i, j, x, y):
    """Localized version of Energy function E.

    Usage: old_x_ij, new_x_ij, E1, E2 = localized_E(Ecur, i, j, x, y)
    """
    oldval = x[i, j]
    newval = oldval * -1  # flip
    # local computations
    E2 = E1 - (h * oldval) + (h * newval)
    E2 = E2 + (eta * y[i, j] * oldval) - (eta * y[i, j] * newval)
    adjacent = [(0, 1), (0, -1), (1, 0), (-1, 0)]
    neighbors = [x[i + di, j + dj] for di, dj in adjacent
                 if ((i+di) >= 0 and (j+dj) >= 0 and (i+di) < x.shape[0] and (j+dj) < x.shape[1])]
    E2 = E2 + beta * sum(a * oldval for a in neighbors)
    E2 = E2 - beta * sum(a * newval for a in neighbors)
    return oldval, newval, E1, E2


def ICM(y):
    """Greedy version of simulated_annealing()."""
    x = np.array(y)
    Ebest = Ecur = E(x, y)  # initial energy

    for idx in np.ndindex(y.shape):  # for each pixel in the matrix
        old, new, E1, E2 = localized_E(Ecur, idx[0], idx[1], x, y)
        if (E2 < Ebest):
            Ecur, x[idx] = E2, new
            Ebest = E2  # update Ebest
        else:
            Ecur, x[idx] = E1, old

    return x


def denoise_image(image):
    """Denoise a binary image.

    Usage: denoised_image, energy_record = denoise_image(image, args, method)
    """
    temp = np.array(image.getdata())
    data = np.vectorize(lambda x: {0: -1, 255: 1}[x])(temp)

#    E, localized_E = E_generator()
#    temp_dir = os.path.dirname(os.path.realpath(args.output))
    y = data.reshape(image.size[::-1])  # convert 1-d array to matrix
    result = ICM(y)
    temp = np.array(result)
    result = np.vectorize(lambda x: {-1: 0, 1: 255}[x])(temp)

    output_image = Image.fromarray(result).convert('1', dither=Image.NONE)
    return output_image


def main():
    src="flipped.png"
    dest="best.png"

    # denoise and save result
    image = Image.open(src)
    result = denoise_image(image)
    result.save(dest)
#    print "[Saved]", args.output


if __name__ == "__main__":
    main()
